import { T as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as Route$21, u as isHome } from "./router-FBojnzgg.mjs";
import { t as ListingCardView } from "./listing-card-Ds-TmwB_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CPaj1NSq.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const search = Route$21.useSearch();
	const [feed, tags, recommended, people] = Route$21.useLoaderData();
	const home = isHome(search);
	const grid = search.kind === "auction" || search.kind === "fixed";
	const pageSize = grid ? 60 : 12;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterBar, {
				search,
				tags,
				showSort: !home && search.kind !== "fixed"
			}),
			home ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl leading-none",
					children: "Топ Аукционов"
				}), recommended.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "border border-dashed border-ink/30 px-4 py-10 text-center text-muted",
					children: "Лотов пока нет."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6",
					children: recommended.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListingCardView, {
						item,
						dense: true
					}, item.id))
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-6",
				children: [people.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl leading-none",
						children: "Люди"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "grid gap-2 sm:grid-cols-2 lg:grid-cols-3",
						children: people.map((person) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/u/$handle",
							params: { handle: person.handle },
							className: "block border border-ink/20 bg-card px-3 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-display text-2xl leading-none",
								children: [person.premium ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "star",
									children: "★ "
								}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: person.premium ? "text-[#e6c36a]" : void 0,
									children: ["@", person.handle]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: person.displayName
							})]
						}) }, person.handle))
					})]
				}) : null, feed.items.length === 0 ? people.length > 0 ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "border border-dashed border-ink/30 px-4 py-10 text-center text-muted",
					children: "По этому запросу лотов нет."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: grid ? "grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6" : "grid gap-8 sm:grid-cols-2 lg:grid-cols-3",
					children: feed.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListingCardView, {
						item,
						dense: grid
					}, item.id))
				})]
			}),
			!home && feed.total > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3 font-mono text-sm",
				children: [
					search.page > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						search: {
							...search,
							page: search.page - 1
						},
						className: "min-h-11 underline",
						children: "Назад"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted tabular-nums",
						children: [
							search.page,
							" / ",
							Math.max(1, Math.ceil(feed.total / pageSize))
						]
					}),
					feed.hasMore ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						search: {
							...search,
							page: search.page + 1
						},
						className: "min-h-11 underline",
						children: "Дальше"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
				]
			}) : null
		]
	});
}
function FilterBar({ search, tags, showSort }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap gap-2",
			children: [[
				["all", "Топ"],
				["auction", "Аукцион"],
				["fixed", "Фикс"]
			].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				search: {
					...search,
					kind: id,
					page: 1,
					...id === "fixed" ? { sort: "new" } : {}
				},
				className: search.kind === id ? "inline-flex min-h-11 items-center border border-wine bg-wine px-3 text-sm text-foam" : "inline-flex min-h-11 items-center border border-ink/25 px-3 text-sm",
				children: label
			}, id)), showSort ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mx-1 hidden w-px bg-ink/15 sm:block" }), [["new", "Новые"], ["ending", "Скоро конец"]].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				search: {
					...search,
					sort: id,
					page: 1
				},
				className: search.sort === id ? "inline-flex min-h-11 items-center border border-wine bg-wine px-3 text-sm text-foam" : "inline-flex min-h-11 items-center border border-ink/25 px-3 text-sm",
				children: label
			}, id))] }) : null]
		}), tags.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex gap-2 overflow-x-auto pb-1",
			children: tags.map((tag) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				search: {
					...search,
					tag: search.tag === tag.slug ? "" : tag.slug,
					page: 1
				},
				className: search.tag === tag.slug ? "shrink-0 border border-wine bg-wine px-2 py-1 font-mono text-xs text-foam" : "shrink-0 border border-ink/25 px-2 py-1 font-mono text-xs",
				children: tag.label
			}, tag.slug))
		}) : null]
	});
}
//#endregion
export { Home as component };
