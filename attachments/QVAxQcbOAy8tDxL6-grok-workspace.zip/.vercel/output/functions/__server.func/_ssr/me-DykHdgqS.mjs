import { o as __toESM } from "../_runtime.mjs";
import { D as profileImageUrl, g as errText, j as statusLabel, k as roleLabel, p as badgeLabel } from "./shared-Bel-W2Fu.mjs";
import { $ as require_react, T as require_jsx_runtime, w as useRouter, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as OVERLAY_IDS, c as THEME_IDS, i as FRAME_LABELS, n as ACCENT_IDS, o as OVERLAY_LABELS, r as FRAME_IDS, s as THEMES, t as ACCENTS } from "./themes-TY6HQGRg.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { N as getMe, it as uploadProfileImage, nt as updateProfileLook, p as useCurrentUserState, tt as updateProfile, w as clearProfileImage } from "./router-FBojnzgg.mjs";
import { a as fieldClass, r as Kicker, t as Button } from "./ui-bits-BXR9txbf.mjs";
import { t as RedirectToSignIn } from "./gates-CUxTjxua.mjs";
import { t as EmojiBar } from "./emoji-bar-CCnR6UyB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/me-DykHdgqS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUSES = [
	"open",
	"busy",
	"closed",
	"away"
];
function MePage() {
	const { user, isPending } = useCurrentUserState();
	const [me, setMe] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!user) return;
		getMe().then(setMe).catch(() => void 0);
	}, [user]);
	if (isPending || user && !me) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-48 animate-pulse bg-soft" });
	if (!user || !me) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Editor, {
		me,
		onSaved: setMe
	});
}
function fileToB64(file) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => {
			const raw = String(reader.result ?? "");
			const cut = raw.indexOf(",");
			resolve(cut >= 0 ? raw.slice(cut + 1) : raw);
		};
		reader.onerror = () => reject(/* @__PURE__ */ new Error("Не удалось прочитать файл"));
		reader.readAsDataURL(file);
	});
}
function Editor({ me, onSaved }) {
	const router = useRouter();
	const [handle, setHandle] = (0, import_react.useState)(me.handle);
	const [displayName, setDisplayName] = (0, import_react.useState)(me.displayName);
	const [bio, setBio] = (0, import_react.useState)(me.bio);
	const [status, setStatus] = (0, import_react.useState)(me.status);
	const [links, setLinks] = (0, import_react.useState)(me.links.length ? me.links : [{
		label: "",
		url: ""
	}]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [stamp, setStamp] = (0, import_react.useState)(Date.now());
	async function saveImage(kind, file) {
		if (!file) return;
		setBusy(true);
		try {
			const b64 = await fileToB64(file);
			await uploadProfileImage({ data: {
				kind,
				b64
			} });
			onSaved(await getMe());
			setStamp(Date.now());
			toast.success("Кадр обновлён");
		} catch (err) {
			toast.error(errText(err));
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-xl gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "grid gap-4",
			onSubmit: (e) => {
				e.preventDefault();
				setBusy(true);
				updateProfile({ data: {
					handle,
					displayName,
					bio,
					status,
					links: links.filter((l) => l.label.trim() || l.url.trim())
				} }).then(async () => {
					toast.success("Профиль сохранён");
					onSaved(await getMe());
					await router.invalidate();
				}).catch((err) => toast.error(errText(err))).finally(() => setBusy(false));
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "you" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-5xl leading-none",
						children: "профиль"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 font-mono text-xs text-muted",
						children: ["роль: ", roleLabel(me.role)]
					}),
					me.premium ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 font-mono text-xs text-[#e6c36a]",
						children: ["★ Premium", me.premiumForever ? " · без срока" : me.premiumUntil ? ` · до ${me.premiumUntil.slice(0, 10)}` : ""]
					}) : null,
					me.badges.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-mono text-xs text-muted",
						children: me.badges.map(badgeLabel).join(" · ")
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/u/$handle",
						params: { handle: me.handle },
						className: "mt-2 inline-flex text-sm underline",
						children: "Открыть публичную страницу"
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageSlot, {
					label: me.premium ? "Аватар, GIF до 1.5 МБ" : "Аватар, до 500 КБ",
					kind: "avatar",
					has: me.hasAvatar,
					handle: me.handle,
					stamp,
					busy,
					onFile: (file) => void saveImage("avatar", file),
					onClear: () => {
						setBusy(true);
						clearProfileImage({ data: "avatar" }).then(() => getMe()).then((next) => {
							onSaved(next);
							setStamp(Date.now());
						}).catch((err) => toast.error(errText(err))).finally(() => setBusy(false));
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageSlot, {
					label: me.premium ? "Баннер, GIF до 3 МБ" : "Баннер шапки, до 1.2 МБ",
					kind: "banner",
					has: me.hasBanner,
					handle: me.handle,
					stamp,
					busy,
					onFile: (file) => void saveImage("banner", file),
					onClear: () => {
						setBusy(true);
						clearProfileImage({ data: "banner" }).then(() => getMe()).then(onSaved).catch((err) => toast.error(errText(err))).finally(() => setBusy(false));
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageSlot, {
					label: me.premium ? "Фон, GIF до 3 МБ" : "Фон профиля, отдельно от баннера, до 1.2 МБ",
					kind: "background",
					has: me.hasBackground,
					handle: me.handle,
					stamp,
					busy,
					onFile: (file) => void saveImage("background", file),
					onClear: () => {
						setBusy(true);
						clearProfileImage({ data: "background" }).then(() => getMe()).then(onSaved).catch((err) => toast.error(errText(err))).finally(() => setBusy(false));
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm",
					children: ["Ник", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: handle,
						onChange: (e) => setHandle(e.target.value),
						className: `${fieldClass} mt-1`
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm",
					children: ["Имя", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: displayName,
						onChange: (e) => setDisplayName(e.target.value),
						className: `${fieldClass} mt-1`
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm",
					children: ["Статус", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: status,
						onChange: (e) => setStatus(e.target.value),
						className: `${fieldClass} mt-1`,
						children: STATUSES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: item,
							children: statusLabel(item)
						}, item))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm",
					children: ["О себе", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-1 flex items-end gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmojiBar, {
							up: true,
							onPick: (emoji) => setBio((value) => value + emoji)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							value: bio,
							onChange: (e) => setBio(e.target.value),
							rows: 4,
							maxLength: 400,
							className: `${fieldClass} min-w-0 flex-1 py-2`
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
					className: "space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
							className: "text-sm",
							children: "Ссылки"
						}),
						links.map((link, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2 sm:grid-cols-[8rem_1fr]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: link.label,
								placeholder: "Подпись",
								maxLength: 24,
								onChange: (e) => {
									const next = links.slice();
									next[index] = {
										...link,
										label: e.target.value
									};
									setLinks(next);
								},
								className: fieldClass
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: link.url,
								placeholder: "https://",
								maxLength: 200,
								onChange: (e) => {
									const next = links.slice();
									next[index] = {
										...link,
										url: e.target.value
									};
									setLinks(next);
								},
								className: fieldClass
							})]
						}, index)),
						links.length < 5 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "font-mono text-xs underline",
							onClick: () => setLinks([...links, {
								label: "",
								url: ""
							}]),
							children: "Ещё ссылка"
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					variant: "wine",
					disabled: busy,
					children: "Сохранить"
				})
			]
		}), me.premium ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LookForm, {
			me,
			onSaved
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "Темы профиля, цвет акцента, рамка аватарки и GIF — только с Premium."
		})]
	});
}
function LookForm({ me, onSaved }) {
	const [theme, setTheme] = (0, import_react.useState)(me.theme);
	const [accent, setAccent] = (0, import_react.useState)(me.accent);
	const [avatarFrame, setAvatarFrame] = (0, import_react.useState)(me.avatarFrame);
	const [bannerOverlay, setBannerOverlay] = (0, import_react.useState)(me.bannerOverlay);
	const [busy, setBusy] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "grid gap-4 border border-[#e6c36a]/50 bg-card p-4",
		onSubmit: (e) => {
			e.preventDefault();
			setBusy(true);
			updateProfileLook({ data: {
				theme,
				accent,
				avatarFrame,
				bannerOverlay
			} }).then(() => getMe()).then((next) => {
				onSaved(next);
				toast.success("Оформление сохранено");
			}).catch((err) => toast.error(errText(err))).finally(() => setBusy(false));
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xl",
				children: "Оформление профиля"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-sm",
				children: ["Тема", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					value: theme,
					onChange: (e) => setTheme(e.target.value),
					className: `${fieldClass} mt-1`,
					children: THEME_IDS.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: id,
						children: THEMES[id].label
					}, id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm",
				children: "Акцент"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 flex flex-wrap gap-2",
				children: ACCENT_IDS.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": ACCENTS[id].label,
					onClick: () => setAccent(id),
					className: accent === id ? "size-9 border-2 border-foam" : "size-9 border border-ink/30",
					style: { background: ACCENTS[id].color }
				}, id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-sm",
				children: ["Рамка аватарки", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					value: avatarFrame,
					onChange: (e) => setAvatarFrame(e.target.value),
					className: `${fieldClass} mt-1`,
					children: FRAME_IDS.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: id,
						children: FRAME_LABELS[id]
					}, id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-sm",
				children: ["Оверлей баннера", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					value: bannerOverlay,
					onChange: (e) => setBannerOverlay(e.target.value),
					className: `${fieldClass} mt-1`,
					children: OVERLAY_IDS.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: id,
						children: OVERLAY_LABELS[id]
					}, id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				variant: "line",
				disabled: busy,
				children: "Сохранить оформление"
			})
		]
	});
}
function ImageSlot({ label, kind, has, handle, stamp, busy, onFile, onClear }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2 border border-ink/15 p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm",
				children: label
			}),
			has ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: `${profileImageUrl(handle, kind)}&v=${stamp}`,
				alt: "",
				className: "max-h-28 w-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-xs text-muted",
				children: "пусто"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "file",
				accept: "image/png,image/jpeg,image/webp,image/gif",
				disabled: busy,
				className: "block w-full text-sm",
				onChange: (e) => {
					const file = e.target.files?.[0];
					e.target.value = "";
					onFile(file);
				}
			}),
			has ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "font-mono text-xs underline",
				disabled: busy,
				onClick: onClear,
				children: "Убрать"
			}) : null
		]
	});
}
//#endregion
export { MePage as component };
