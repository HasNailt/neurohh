import { o as __toESM } from "../_runtime.mjs";
import { $ as require_react, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as getBearerToken } from "./client-BDq8GlIC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/chat-picture-B--vjGSI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Loads the original bytes. The server does not recompress chat pictures. */
function ChatPictures({ images }) {
	if (images.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-2 flex flex-nowrap gap-2 overflow-x-auto",
		children: images.map((image) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatPicture, { image }, image.id))
	});
}
function ChatPicture({ image }) {
	const [url, setUrl] = (0, import_react.useState)(null);
	const [failed, setFailed] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let stop = false;
		let objectUrl = "";
		const headers = new Headers();
		const token = getBearerToken();
		if (token) headers.set("Authorization", `Bearer ${token}`);
		fetch(`/api/chat-image/${image.id}`, {
			headers,
			credentials: "include"
		}).then((res) => {
			if (!res.ok) throw new Error("no");
			return res.blob();
		}).then((blob) => {
			if (stop) return;
			objectUrl = URL.createObjectURL(blob);
			setUrl(objectUrl);
		}).catch(() => {
			if (!stop) setFailed(true);
		});
		return () => {
			stop = true;
			if (objectUrl) URL.revokeObjectURL(objectUrl);
		};
	}, [image.id]);
	function save() {
		if (!url) return;
		const link = document.createElement("a");
		link.href = url;
		link.download = image.filename || "image";
		link.click();
	}
	if (failed) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "font-mono text-xs text-muted",
		children: "нет файла"
	});
	if (!url) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "inline-block h-24 w-24 shrink-0 animate-pulse bg-soft" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick: save,
		title: "Скачать",
		className: "shrink-0",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: url,
			alt: "",
			className: "h-24 w-24 border border-ink/20 object-cover"
		})
	});
}
//#endregion
export { ChatPictures as t };
