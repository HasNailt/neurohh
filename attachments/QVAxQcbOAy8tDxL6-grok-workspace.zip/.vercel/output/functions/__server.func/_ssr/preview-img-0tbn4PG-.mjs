import { o as __toESM } from "../_runtime.mjs";
import { $ as require_react, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { I as imageData } from "./router-FBojnzgg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/preview-img-0tbn4PG-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var cache = /* @__PURE__ */ new Map();
var running = 0;
var waiters = [];
function enqueue(job) {
	return new Promise((resolve, reject) => {
		const start = () => {
			running += 1;
			job().then(resolve, reject).finally(() => {
				running -= 1;
				waiters.shift()?.();
			});
		};
		if (running < 2) start();
		else waiters.push(start);
	});
}
function PreviewImg({ id, src, variant = "card", alt, className, fallback }) {
	const [url, setUrl] = (0, import_react.useState)(src ?? null);
	const [pending, setPending] = (0, import_react.useState)(!src && Boolean(id));
	(0, import_react.useEffect)(() => {
		if (src) {
			setUrl(src);
			setPending(false);
			return;
		}
		if (!id) {
			setPending(false);
			return;
		}
		const key = `${variant}:${id}`;
		if (cache.has(key)) {
			setUrl(cache.get(key) ?? null);
			setPending(false);
			return;
		}
		let stop = false;
		setPending(true);
		enqueue(() => imageData({ data: {
			id,
			variant
		} })).then((res) => {
			cache.set(key, res.src);
			if (!stop) setUrl(res.src);
		}).catch(() => {
			cache.set(key, null);
			if (!stop) setUrl(null);
		}).finally(() => {
			if (!stop) setPending(false);
		});
		return () => {
			stop = true;
		};
	}, [
		id,
		src,
		variant
	]);
	if (!url && pending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full w-full animate-pulse bg-soft" });
	if (!url) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: fallback ?? null });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: url,
		alt,
		className,
		loading: "lazy",
		decoding: "async"
	});
}
//#endregion
export { PreviewImg as t };
