import { o as __toESM } from "../_runtime.mjs";
import { D as profileImageUrl, b as formatWhen, g as errText, j as statusLabel, k as roleLabel, p as badgeLabel } from "./shared-Bel-W2Fu.mjs";
import { $ as require_react, T as require_jsx_runtime, w as useRouter, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as THEMES, t as ACCENTS } from "./themes-TY6HQGRg.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { B as listProfileLots, N as getMe, Q as toggleFollow, d as siteThemeSnapshot, f as subscribeSiteTheme, p as useCurrentUserState, r as Route$5 } from "./router-FBojnzgg.mjs";
import { t as ListingCardView } from "./listing-card-Ds-TmwB_.mjs";
import { n as PremiumBadge, t as Nick } from "./nick-BpIOwPBG.mjs";
import { t as PostCard } from "./post-card-FTsekDbH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/u._handle-D4JWuNw-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function followerWord(n) {
	const mod10 = n % 10;
	const mod100 = n % 100;
	if (mod10 === 1 && mod100 !== 11) return "подписчик";
	if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) return "подписчика";
	return "подписчиков";
}
function lightSurface(bg) {
	const hex = bg.replace("#", "");
	if (hex.length < 6) return false;
	const r = Number.parseInt(hex.slice(0, 2), 16);
	const g = Number.parseInt(hex.slice(2, 4), 16);
	const b = Number.parseInt(hex.slice(4, 6), 16);
	if ([
		r,
		g,
		b
	].some((n) => Number.isNaN(n))) return false;
	return (r * 299 + g * 587 + b * 114) / 1e3 > 150;
}
function ProfilePage() {
	const loaded = Route$5.useLoaderData();
	const router = useRouter();
	const { user } = useCurrentUserState();
	const [me, setMe] = (0, import_react.useState)(null);
	const [tab, setTab] = (0, import_react.useState)("lots");
	const [page, setPage] = (0, import_react.useState)(1);
	const [lots, setLots] = (0, import_react.useState)(loaded?.lots ?? []);
	const [total, setTotal] = (0, import_react.useState)(loaded?.lotTotal ?? 0);
	const site = (0, import_react.useSyncExternalStore)(subscribeSiteTheme, siteThemeSnapshot, () => "dark");
	(0, import_react.useEffect)(() => {
		if (!user) {
			setMe(null);
			return;
		}
		getMe().then(setMe).catch(() => void 0);
	}, [user]);
	(0, import_react.useEffect)(() => {
		if (!loaded) return;
		setLots(loaded.lots);
		setTotal(loaded.lotTotal);
		setPage(1);
	}, [loaded]);
	if (!loaded) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
		className: "font-display text-4xl",
		children: "Такого профиля нет"
	});
	const profile = loaded;
	const preset = THEMES[profile.theme];
	const theme = profile.theme === "classic" && !profile.premium && site === "light" ? {
		...preset,
		bg: "#eceae6",
		ink: "#1c1b19",
		muted: "#5f5b55",
		card: "#f7f6f3",
		line: "rgba(28,27,25,0.16)",
		foam: "#f7f4ef"
	} : preset;
	const hud = lightSurface(theme.bg) ? theme.ink : theme.foam;
	const bg = profile.hasBackground ? profileImageUrl(profile.handle, "background") : "";
	const banner = profile.hasBanner ? profileImageUrl(profile.handle, "banner") : "";
	const pages = Math.max(1, Math.ceil(total / 60));
	function openPage(next) {
		setPage(next);
		if (next === 1) {
			setLots(profile.lots);
			return;
		}
		listProfileLots({ data: {
			handle: profile.handle,
			page: next
		} }).then((res) => {
			setLots(res.items);
			setTotal(res.total);
		}).catch((err) => toast.error(errText(err)));
	}
	const accent = ACCENTS[profile.accent].color;
	const scope = {
		color: theme.ink,
		background: theme.bg,
		["--p-bg"]: theme.bg,
		["--p-ink"]: theme.ink,
		["--p-muted"]: theme.muted,
		["--p-card"]: theme.card,
		["--p-accent"]: accent,
		["--p-line"]: theme.line,
		["--p-foam"]: theme.foam
	};
	const bannerStyle = bannerLayer(profile.bannerOverlay, banner, theme.bg);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "profile-scope -mx-4 space-y-8 px-4 py-6 sm:-mx-0 sm:px-4",
		style: scope,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "theme-card relative z-0 overflow-hidden border",
				style: bg ? {
					backgroundImage: `url(${bg})`,
					backgroundSize: "cover",
					backgroundPosition: "center"
				} : { background: theme.card },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: bg ? { background: `${theme.bg}cc` } : void 0,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative h-36 border-b sm:h-48",
						style: {
							borderColor: theme.line,
							...bannerStyle
						},
						children: [
							banner ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute inset-0",
								style: { background: `linear-gradient(135deg, ${accent} 0%, ${theme.bg} 55%, ${theme.card} 100%)` }
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "pointer-events-none absolute top-3 left-3 h-3 w-3 border-t border-l",
								style: { borderColor: hud }
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "pointer-events-none absolute top-3 right-3 h-3 w-3 border-t border-r",
								style: { borderColor: hud }
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "absolute bottom-3 left-36 font-mono text-[10px] tracking-[0.22em] uppercase sm:left-44",
								style: { color: hud },
								children: ["// ", profile.handle]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative px-4 pt-0 pb-5 sm:px-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "-mt-10 flex flex-wrap items-end justify-between gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-end gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `relative grid size-24 place-items-center overflow-hidden sm:size-28 ${avatarFrameClass(profile.avatarFrame)}`,
										style: {
											borderColor: profile.avatarFrame === "gold" ? "#e6c36a" : accent,
											background: theme.card
										},
										children: profile.hasAvatar ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: profileImageUrl(profile.handle, "avatar"),
											alt: "",
											className: "h-full w-full object-cover"
										}) : null
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "pb-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
											className: "font-display text-4xl leading-none sm:text-5xl",
											children: profile.displayName
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 font-mono text-sm",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nick, {
												handle: profile.handle,
												premium: profile.premium
											})
										})]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileActions, {
									profile,
									onFollow: () => void router.invalidate()
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex flex-wrap items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "theme-chip border px-2 py-1 font-mono text-xs",
										children: statusLabel(profile.status)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "theme-chip border px-2 py-1 font-mono text-xs",
										children: [
											profile.followers,
											" ",
											followerWord(profile.followers)
										]
									}),
									profile.premium ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PremiumBadge, {}) : null,
									profile.isNew ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "border px-2 py-1 font-mono text-xs",
										style: { borderColor: theme.line },
										children: "Новый пользователь"
									}) : null,
									profile.badges.map((badge) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "border px-2 py-1 font-mono text-xs",
										style: { borderColor: theme.line },
										children: badgeLabel(badge)
									}, badge)),
									profile.role !== "user" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "border border-ink/30 px-2 py-1 font-mono text-xs",
										children: roleLabel(profile.role)
									}) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-mono text-xs text-muted",
										suppressHydrationWarning: true,
										children: ["на площадке с ", formatWhen(profile.createdAt)]
									})
								]
							}),
							profile.bio ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 max-w-prose whitespace-pre-wrap",
								children: profile.bio
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-sm text-muted",
								children: "Описание пока пустое."
							}),
							profile.links.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-4 flex flex-wrap gap-2",
								children: profile.links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: link.url,
									target: "_blank",
									rel: "noreferrer",
									className: "inline-flex min-h-9 items-center border border-ink/25 px-3 text-sm hover:border-wine",
									children: link.label
								}) }, `${link.label}-${link.url}`))
							}) : null
						]
					})]
				})
			}),
			(profile.lots.some((item) => item.pinned) || profile.posts.some((post) => post.pinned)) && page === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs tracking-widest uppercase",
						style: { color: "var(--p-muted)" },
						children: "закреплено"
					}),
					profile.lots.some((item) => item.pinned) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6",
						children: profile.lots.filter((item) => item.pinned).slice(0, 3).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListingCardView, {
							item,
							showPrice: false,
							dense: true
						}, item.id))
					}) : null,
					profile.posts.some((post) => post.pinned) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto max-w-5xl space-y-3",
						children: profile.posts.filter((post) => post.pinned).slice(0, 3).map((post) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostCard, {
							post,
							mine: me?.handle === profile.handle,
							onChange: () => void router.invalidate()
						}, post.id))
					}) : null
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: tab === "lots" ? "theme-chip min-h-11 border px-4" : "min-h-11 border px-4",
					style: tab === "lots" ? void 0 : {
						borderColor: "var(--p-line)",
						color: "var(--p-ink)"
					},
					onClick: () => setTab("lots"),
					children: "Лоты"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: tab === "posts" ? "theme-chip min-h-11 border px-4" : "min-h-11 border px-4",
					style: tab === "posts" ? void 0 : {
						borderColor: "var(--p-line)",
						color: "var(--p-ink)"
					},
					onClick: () => setTab("posts"),
					children: "Посты"
				})]
			}),
			tab === "lots" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-4",
				children: [lots.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted",
					children: "Лотов нет."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6",
					children: lots.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListingCardView, {
						item,
						showPrice: false,
						dense: true
					}, item.id))
				}), pages > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between font-mono text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "min-h-11 underline disabled:opacity-40",
							disabled: page <= 1,
							onClick: () => openPage(page - 1),
							children: "Назад"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted tabular-nums",
							children: [
								page,
								" / ",
								pages
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "min-h-11 underline disabled:opacity-40",
							disabled: page >= pages,
							onClick: () => openPage(page + 1),
							children: "Дальше"
						})
					]
				}) : null]
			}) : profile.posts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: "Постов пока нет."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto max-w-5xl space-y-4",
				children: profile.posts.map((post) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostCard, {
					post,
					mine: me?.handle === profile.handle || me?.role === "admin" || me?.role === "moderator",
					onChange: () => void router.invalidate()
				}, post.id))
			})
		]
	});
}
function ProfileActions({ profile, onFollow }) {
	const { user } = useCurrentUserState();
	const [me, setMe] = (0, import_react.useState)(null);
	const [following, setFollowing] = (0, import_react.useState)(profile.following);
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setFollowing(profile.following);
	}, [profile.following]);
	(0, import_react.useEffect)(() => {
		if (!user) {
			setMe(null);
			return;
		}
		getMe().then(setMe).catch(() => void 0);
	}, [user]);
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/login",
		className: "inline-flex min-h-11 items-center border border-wine bg-wine px-4 text-foam",
		children: "Чат"
	});
	if (me?.handle === profile.handle) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/me",
		className: "inline-flex min-h-11 items-center border border-ink/30 px-4",
		children: "Править профиль"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			disabled: busy,
			className: following ? "min-h-11 border border-ink/30 px-4" : "min-h-11 border border-wine bg-wine px-4 text-foam",
			onClick: () => {
				setBusy(true);
				toggleFollow({ data: profile.handle }).then((res) => {
					setFollowing(res.following);
					onFollow();
				}).catch((err) => toast.error(errText(err))).finally(() => setBusy(false));
			},
			children: following ? "Отписаться" : "Подписаться"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/chats",
			search: { with: profile.handle },
			className: "inline-flex min-h-11 items-center border border-ink/30 px-4",
			children: "Чат"
		})]
	});
}
function avatarFrameClass(frame) {
	if (frame === "circle" || frame === "gold") return "rounded-full border-2";
	if (frame === "rounded") return "rounded-2xl border";
	if (frame === "none") return "";
	return "border";
}
function bannerLayer(overlay, banner, bg) {
	if (!banner) return {};
	const image = `url(${banner})`;
	const cover = {
		backgroundSize: "cover",
		backgroundPosition: "center"
	};
	if (overlay === "none") return {
		backgroundImage: image,
		...cover
	};
	if (overlay === "darken") return {
		backgroundImage: `linear-gradient(rgba(0,0,0,.5), rgba(0,0,0,.5)), ${image}`,
		...cover
	};
	if (overlay === "vignette") return {
		backgroundImage: `radial-gradient(ellipse at center, transparent 35%, rgba(0,0,0,.62)), ${image}`,
		...cover
	};
	return {
		backgroundImage: `linear-gradient(to top, ${bg}, transparent 55%), ${image}`,
		...cover
	};
}
//#endregion
export { ProfilePage as component };
