import { o as __toESM } from "../_runtime.mjs";
import { _ as formatDealNo, y as formatPrice } from "./shared-Bel-W2Fu.mjs";
import { $ as require_react, T as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { L as listDeals, p as useCurrentUserState } from "./router-FBojnzgg.mjs";
import { n as Frame, r as Kicker } from "./ui-bits-BXR9txbf.mjs";
import { t as RedirectToSignIn } from "./gates-CUxTjxua.mjs";
import { t as PreviewImg } from "./preview-img-0tbn4PG-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/deals.index-_QCTbvA5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DealsPage() {
	const { user, isPending } = useCurrentUserState();
	const [deals, setDeals] = (0, import_react.useState)(null);
	const [filter, setFilter] = (0, import_react.useState)("all");
	(0, import_react.useEffect)(() => {
		if (!user) return;
		listDeals().then(setDeals).catch(() => setDeals([]));
	}, [user]);
	const visible = (deals ?? []).filter((deal) => {
		if (filter === "open") return deal.status !== "completed";
		if (filter === "closed") return deal.status === "completed";
		return true;
	});
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40 animate-pulse bg-soft" });
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "trades" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-5xl leading-none",
				children: "сделки"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					["all", "Все"],
					["open", "Открытые"],
					["closed", "Закрытые"]
				].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: filter === id ? "min-h-11 border border-wine bg-wine px-3 text-foam" : "min-h-11 border border-ink/25 px-3",
					onClick: () => setFilter(id),
					children: label
				}, id))
			}),
			deals == null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40 animate-pulse bg-soft" }) : visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: deals.length === 0 ? "Пока пусто. Сделка появляется после покупки или победы на аукционе." : "В этом фильтре сделок нет."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-3",
				children: visible.map((deal) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/deals/$id",
					params: { id: deal.id },
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 bg-card p-3",
						children: [
							deal.previewId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewImg, {
								id: deal.previewId,
								alt: "",
								className: "h-16 w-12 object-cover"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid h-16 w-12 place-items-center bg-wine-deep font-display text-foam",
								children: deal.title.slice(0, 1)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-display text-xl",
									children: deal.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-mono text-xs text-muted",
									children: [
										formatDealNo(deal.publicNo),
										" ·",
										" ",
										deal.youAre === "seller" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
											"покупатель ",
											deal.buyerPremium ? "★ " : "",
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: deal.buyerPremium ? "text-[#e6c36a]" : void 0,
												children: ["@", deal.buyerHandle]
											})
										] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
											"продавец ",
											deal.sellerPremium ? "★ " : "",
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: deal.sellerPremium ? "text-[#e6c36a]" : void 0,
												children: ["@", deal.sellerHandle]
											})
										] })
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: deal.status === "completed" ? "border border-ink/30 px-2 py-1 font-mono text-xs" : "border border-wine bg-wine px-2 py-1 font-mono text-xs text-foam",
									children: deal.status === "completed" ? "Закрыта" : "Открыта"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 font-mono text-sm tabular-nums",
									children: formatPrice(deal.amount)
								})]
							})
						]
					}) })
				}) }, deal.id))
			})
		]
	});
}
//#endregion
export { DealsPage as component };
