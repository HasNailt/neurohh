import { o as __toESM } from "../_runtime.mjs";
import { b as formatWhen, g as errText, y as formatPrice } from "./shared-Bel-W2Fu.mjs";
import { $ as require_react, C as useNavigate, T as require_jsx_runtime, w as useRouter, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { $ as toggleLike, C as buyNow, G as reportListing, S as buyFixed, U as placeBid, g as addListingComment, i as Route$6, p as useCurrentUserState } from "./router-FBojnzgg.mjs";
import { a as fieldClass, i as StatusChip, n as Frame, r as Kicker, t as Button } from "./ui-bits-BXR9txbf.mjs";
import { t as EmojiBar } from "./emoji-bar-CCnR6UyB.mjs";
import { t as PreviewImg } from "./preview-img-0tbn4PG-.mjs";
import { t as Nick } from "./nick-BpIOwPBG.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/lot._id-Ccy74h8v.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function snipeLabel(minutes) {
	if (minutes <= 0) return "антиснайп выключен";
	if (minutes === 60) return "антиснайп 1 час";
	return `антиснайп ${minutes} мин`;
}
function LotPage() {
	const lot = Route$6.useLoaderData();
	if (!lot) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "404" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-5xl leading-none",
				children: "лот не найден."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				search: {
					q: "",
					tag: "",
					kind: "all",
					sort: "new",
					page: 1
				},
				className: "font-mono text-sm text-muted hover:text-ink",
				children: "в ленту"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LotView, { lot });
}
function LotView({ lot }) {
	const { user } = useCurrentUserState();
	const router = useRouter();
	const navigate = useNavigate();
	const mine = user?.id === lot.sellerId;
	const live = lot.status === "active";
	const [liked, setLiked] = (0, import_react.useState)(lot.liked);
	const [likes, setLikes] = (0, import_react.useState)(lot.likeCount);
	const [bid, setBid] = (0, import_react.useState)("");
	const [comment, setComment] = (0, import_react.useState)("");
	const [reason, setReason] = (0, import_react.useState)("");
	const [reportOpen, setReportOpen] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const floor = (lot.currentBid ?? lot.price - 1) + 1;
	const showBuyNow = live && !mine && lot.kind === "auction" && lot.buyNow != null && (lot.currentBid == null || lot.currentBid < lot.buyNow);
	async function run(job) {
		setBusy(true);
		try {
			await job();
			await router.invalidate();
		} catch (err) {
			toast.error(errText(err));
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-8 lg:grid-cols-[minmax(0,1.2fr)_minmax(280px,0.8fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gallery, { lot }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border border-ink/20 bg-card p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: lot.kind === "auction" ? "auction" : "fixed" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-2 font-display text-2xl leading-tight",
							children: lot.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 whitespace-pre-wrap text-base text-ink/90",
							children: lot.blurb || "Без короткого описания."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-base text-ink/90",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nick, {
								handle: lot.sellerHandle,
								premium: lot.sellerPremium
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-muted",
								children: [
									" · ",
									formatWhen(lot.createdAt),
									lot.kind === "auction" ? ` · ${snipeLabel(lot.antiSnipeMinutes)}` : ""
								]
							})]
						}),
						mine && lot.privateDescription ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 border border-ink/15 bg-card px-3 py-2 text-sm text-muted",
							children: ["Для вас: ", lot.privateDescription]
						}) : null,
						lot.tags.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 flex flex-wrap gap-1.5",
							children: lot.tags.map((tag) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/",
								search: {
									q: "",
									tag: tag.slug,
									kind: "all",
									sort: "new",
									page: 1
								},
								className: "border border-ink/25 px-2 py-1 font-mono text-xs hover:border-wine",
								children: tag.label
							}, tag.slug))
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "notes" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "space-y-2",
							children: [lot.comments.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "text-sm text-muted",
								children: "Комментариев пока нет."
							}) : null, lot.comments.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "border border-ink/15 bg-card px-3 py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-mono text-xs text-muted",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nick, {
											handle: item.authorHandle,
											premium: item.authorPremium
										}),
										" · ",
										formatWhen(item.createdAt)
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 whitespace-pre-wrap",
									children: item.body
								})]
							}, item.id))]
						}),
						user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "flex items-center gap-2",
							onSubmit: (event) => {
								event.preventDefault();
								const body = comment.trim();
								if (!body) return;
								run(async () => {
									await addListingComment({ data: {
										listingId: lot.id,
										body
									} });
									setComment("");
								});
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmojiBar, {
									up: true,
									onPick: (emoji) => setComment((value) => value + emoji)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: comment,
									onChange: (e) => setComment(e.target.value),
									placeholder: "Комментарий",
									className: `${fieldClass} min-w-0 flex-1`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									variant: "line",
									disabled: busy,
									children: "ок"
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/login",
							className: "font-mono text-xs text-muted hover:text-ink",
							children: "войдите, чтобы комментировать"
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3 bg-card p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusChip, {
								kind: "listing",
								status: lot.status
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "inline-flex min-h-11 items-center gap-1.5 border border-ink/25 px-3 font-mono text-lg leading-none",
								onClick: () => {
									if (!user) {
										toast.error("Войдите, чтобы отметить лот");
										return;
									}
									run(async () => {
										const res = await toggleLike({ data: lot.id });
										setLiked(res.liked);
										setLikes((n) => n + (res.liked ? 1 : -1));
									});
								},
								children: [
									liked ? "♥" : "♡",
									" ",
									Math.max(0, likes)
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-4xl tabular-nums leading-none",
							children: formatPrice(lot.kind === "auction" ? lot.currentBid ?? lot.price : lot.price)
						}),
						lot.kind === "auction" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono text-xs text-muted",
							children: [
								"старт ",
								formatPrice(lot.price),
								lot.bidCount > 0 ? ` · ${lot.bidCount} став.` : "",
								lot.buyNow != null ? ` · сразу ${formatPrice(lot.buyNow)}` : ""
							]
						}) : null,
						lot.kind === "auction" && lot.endsAt && live ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Countdown, { endsAt: lot.endsAt }) : null,
						lot.dealId && user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/deals/$id",
							params: { id: lot.dealId },
							className: "inline-flex font-mono text-sm text-wine hover:underline",
							children: "открыть сделку"
						}) : null,
						live && lot.kind === "auction" && user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "space-y-2",
							onSubmit: (event) => {
								event.preventDefault();
								const amount = Number(bid);
								run(async () => {
									const res = await placeBid({ data: {
										listingId: lot.id,
										amount
									} });
									toast.success(res.extended ? "Ставка принята, аукцион продлён" : "Ставка принята");
									setBid("");
								});
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: bid,
									onChange: (e) => setBid(e.target.value),
									inputMode: "numeric",
									placeholder: `от ${floor} ₽`,
									className: `${fieldClass} tabular-nums`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									disabled: busy,
									className: "w-full",
									children: user && lot.currentBidderId === user.id ? "Перебить свою" : mine ? "Своя ставка" : "Поставить"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono text-xs text-muted",
									children: "Можно перебить свою ставку — сумма должна быть выше текущей."
								})
							]
						}) : null,
						showBuyNow ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "wine",
							className: "w-full",
							disabled: busy,
							onClick: () => void run(async () => {
								const res = await buyNow({ data: lot.id });
								toast.success("Лот ваш");
								await navigate({
									to: "/deals/$id",
									params: { id: res.dealId }
								});
							}),
							children: ["Купить сейчас · ", formatPrice(lot.buyNow ?? 0)]
						}) : null,
						live && lot.kind === "fixed" && user && !mine ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							className: "w-full",
							disabled: busy,
							onClick: () => void run(async () => {
								const res = await buyFixed({ data: lot.id });
								toast.success("Лот ваш");
								await navigate({
									to: "/deals/$id",
									params: { id: res.dealId }
								});
							}),
							children: ["Забрать за ", formatPrice(lot.price)]
						}) : null,
						!user && live ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/login",
							className: "block text-center font-mono text-xs text-muted hover:text-ink",
							children: "войдите, чтобы участвовать"
						}) : null
					]
				}) }),
				lot.kind === "auction" && lot.bids.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-card p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "bids" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-2 text-base",
						children: lot.bids.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-baseline justify-between gap-3 border-b border-ink/10 pb-2 last:border-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/u/$handle",
								params: { handle: row.handle },
								className: "hover:text-ink",
								children: [row.premium ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "star",
									children: "★ "
								}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: row.premium ? "text-[#e6c36a]" : void 0,
									children: ["@", row.handle]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-lg tabular-nums",
								children: formatPrice(row.amount)
							})]
						}, row.id))
					})]
				}) }) : null,
				user && !mine ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "font-mono text-xs text-muted hover:text-ink",
					onClick: () => setReportOpen((v) => !v),
					children: "пожаловаться"
				}), reportOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-2 space-y-2",
					onSubmit: (event) => {
						event.preventDefault();
						run(async () => {
							await reportListing({ data: {
								listingId: lot.id,
								reason
							} });
							setReason("");
							setReportOpen(false);
							toast.success("Жалоба отправлена");
						});
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmojiBar, {
							up: true,
							onPick: (emoji) => setReason((value) => value + emoji)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							value: reason,
							onChange: (e) => setReason(e.target.value),
							rows: 3,
							className: `${fieldClass} min-w-0 flex-1 py-2`,
							placeholder: "Что не так с лотом"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						variant: "line",
						disabled: busy,
						children: "отправить"
					})]
				}) : null] }) : null
			]
		})]
	});
}
function Gallery({ lot }) {
	const [active, setActive] = (0, import_react.useState)(lot.previews[0]?.id ?? "");
	(0, import_react.useEffect)(() => {
		setActive(lot.previews[0]?.id ?? "");
	}, [lot.id, lot.previews]);
	const letter = (lot.title.trim()[0] || "A").toLocaleUpperCase("ru");
	const current = lot.previews.find((p) => p.id === active) ?? lot.previews[0];
	if (!current) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "poster grid place-items-center bg-wine-deep",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-display text-8xl leading-none text-foam",
			children: letter
		})
	}) });
	const fallback = /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "poster grid place-items-center bg-wine-deep",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-display text-8xl leading-none text-foam",
			children: letter
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewImg, {
			id: current.id,
			src: current.src || current.card,
			variant: "view",
			alt: lot.title,
			className: "max-h-[70vh] w-full bg-soft object-contain",
			fallback
		}) }), lot.previews.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex gap-2 overflow-x-auto",
			children: lot.previews.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setActive(p.id),
				className: p.id === active ? "border-2 border-ink" : "border border-ink/20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewImg, {
					id: p.id,
					src: p.card || p.src,
					alt: "",
					className: "h-16 w-14 object-cover"
				})
			}, p.id))
		}) : null]
	});
}
function Countdown({ endsAt }) {
	const [text, setText] = (0, import_react.useState)("···");
	(0, import_react.useEffect)(() => {
		const tick = () => {
			const ms = new Date(endsAt).getTime() - Date.now();
			if (ms <= 0) {
				setText("00:00:00");
				return;
			}
			const s = Math.floor(ms / 1e3);
			const d = Math.floor(s / 86400);
			const h = Math.floor(s % 86400 / 3600);
			const m = Math.floor(s % 3600 / 60);
			const sec = s % 60;
			const pad = (n) => String(n).padStart(2, "0");
			setText(d > 0 ? `${d}д ${pad(h)}:${pad(m)}:${pad(sec)}` : `${pad(h)}:${pad(m)}:${pad(sec)}`);
		};
		tick();
		const id = window.setInterval(tick, 1e3);
		return () => window.clearInterval(id);
	}, [endsAt]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "font-mono text-sm tabular-nums",
		children: ["до конца ", text]
	});
}
//#endregion
export { LotPage as component };
