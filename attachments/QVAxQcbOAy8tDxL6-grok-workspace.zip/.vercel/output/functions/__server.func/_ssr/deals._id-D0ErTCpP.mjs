import { o as __toESM } from "../_runtime.mjs";
import { _ as formatDealNo, b as formatWhen, g as errText, y as formatPrice } from "./shared-Bel-W2Fu.mjs";
import { $ as require_react, T as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { J as setDealOpen, a as Route$7, j as getDeal, k as discardBlankMessage, p as useCurrentUserState, q as sendMessage } from "./router-FBojnzgg.mjs";
import { a as fieldClass, t as Button } from "./ui-bits-BXR9txbf.mjs";
import { t as RedirectToSignIn } from "./gates-CUxTjxua.mjs";
import { t as ChatPictures } from "./chat-picture-B--vjGSI.mjs";
import { t as EmojiBar } from "./emoji-bar-CCnR6UyB.mjs";
import { r as pushChatImage, t as checkChatImage } from "./client-upload-CqcvdaE0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/deals._id-D0ErTCpP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DealPage() {
	const { id } = Route$7.useParams();
	const { user, isPending } = useCurrentUserState();
	const [deal, setDeal] = (0, import_react.useState)(void 0);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [pics, setPics] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const scroller = (0, import_react.useRef)(null);
	const stick = (0, import_react.useRef)(true);
	(0, import_react.useEffect)(() => {
		if (!user) return;
		let stop = false;
		const load = () => {
			getDeal({ data: id }).then((next) => {
				if (!stop) setDeal(next);
			}).catch((err) => {
				if (!stop) {
					setDeal(null);
					toast.error(errText(err));
				}
			});
		};
		load();
		const timer = window.setInterval(load, 4e3);
		return () => {
			stop = true;
			window.clearInterval(timer);
		};
	}, [user, id]);
	(0, import_react.useEffect)(() => {
		const el = scroller.current;
		if (!el || !stick.current) return;
		el.scrollTop = el.scrollHeight;
	}, [deal?.messages.length, deal?.messages.reduce((sum, message) => sum + message.images.length, 0)]);
	if (isPending || user && deal === void 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-64 animate-pulse bg-soft" });
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	if (!deal) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
		className: "font-display text-4xl",
		children: "Сделка не найдена"
	});
	const other = deal.youAre === "seller" ? deal.buyer : deal.seller;
	async function act(fn, ok) {
		setBusy(true);
		try {
			const next = await fn();
			setDeal(next);
			toast.success(ok);
		} catch (err) {
			toast.error(errText(err));
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid items-start gap-4 lg:grid-cols-[minmax(0,1fr)_18rem]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl leading-none",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/lot/$id",
					params: { id: deal.listingId },
					className: "hover:underline",
					children: deal.title
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex h-[70vh] min-h-96 flex-col border border-ink/20 bg-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					ref: scroller,
					onScroll: (e) => {
						const el = e.currentTarget;
						stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
					},
					className: "flex-1 space-y-3 overflow-y-auto p-4",
					children: deal.messages.map((message) => message.system ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-center font-mono text-xs text-muted",
						children: message.body
					}, message.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: message.senderId === user.id ? "ml-auto max-w-[80%]" : "max-w-[80%]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mb-1 font-mono text-[10px] tracking-wide text-muted uppercase",
							children: [
								message.premium ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "star",
									children: "★ "
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: message.premium ? "text-[#e6c36a]" : void 0,
									children: ["@", message.handle]
								}),
								" · ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									suppressHydrationWarning: true,
									children: formatWhen(message.createdAt)
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: message.senderId === user.id ? "bg-wine px-3 py-2 text-foam" : "border border-ink/20 bg-paper px-3 py-2",
							children: [message.body ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "whitespace-pre-wrap",
								children: message.body
							}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatPictures, { images: message.images })]
						})]
					}, message.id))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "space-y-2 border-t border-ink/15 p-3",
					onSubmit: (e) => {
						e.preventDefault();
						const body = draft.trim();
						const files = pics.slice(0, 10);
						if (!body && files.length === 0) return;
						if (pics.length > 10) {
							toast.error("Не больше 10 картинок в одном сообщении");
							return;
						}
						setBusy(true);
						(async () => {
							let messageId = null;
							try {
								for (const file of files) await checkChatImage(file);
								const created = await sendMessage({ data: {
									dealId: deal.id,
									body,
									withImages: files.length > 0
								} });
								messageId = created.id;
								for (const file of files) await pushChatImage(created.id, file);
								const next = await getDeal({ data: deal.id });
								if (next) setDeal(next);
								setDraft("");
								setPics([]);
								stick.current = true;
							} catch (err) {
								if (messageId && !body) await discardBlankMessage({ data: messageId }).catch(() => void 0);
								toast.error(errText(err));
							} finally {
								setBusy(false);
							}
						})();
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm",
						children: [
							"Картинки",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "file",
								accept: "image/png,image/jpeg,image/webp,image/gif",
								multiple: true,
								className: "mt-1 block w-full cursor-pointer text-sm file:mr-3 file:inline-flex file:min-h-11 file:cursor-pointer file:border-0 file:bg-wine file:px-3 file:py-2 file:text-foam",
								onChange: (e) => {
									const picked = Array.from(e.target.files ?? []);
									e.currentTarget.value = "";
									if (picked.length > 10) {
										toast.error("Не больше 10 картинок в одном сообщении");
										setPics([]);
										return;
									}
									(async () => {
										try {
											for (const file of picked) await checkChatImage(file);
											setPics(picked);
										} catch (err) {
											setPics([]);
											toast.error(errText(err));
										}
									})();
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mt-1 block font-mono text-xs text-muted",
								children: ["До 10, каждая до 3 МБ и 3000×3000. Без сжатия — скачивается как загрузили.", pics.length > 0 ? ` Выбрано: ${pics.map((f) => f.name).join(", ")}` : ""]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmojiBar, {
								up: true,
								onPick: (emoji) => setDraft((value) => value + emoji)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: draft,
								onChange: (e) => setDraft(e.target.value),
								placeholder: "Сообщение",
								className: `${fieldClass} min-w-0 flex-1`,
								maxLength: 2e3
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								disabled: busy,
								children: "Ок"
							})
						]
					})]
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
			className: "lg:sticky lg:top-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4 border border-ink/20 bg-card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-[10px] tracking-[0.18em] text-muted uppercase",
							children: deal.youAre === "seller" ? "покупатель" : "продавец"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/u/$handle",
							params: { handle: other.handle },
							className: "mt-1 block font-display text-3xl leading-none hover:underline",
							children: [other.premium ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "star",
								children: "★ "
							}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: other.premium ? "text-[#e6c36a]" : void 0,
								children: ["@", other.handle]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: other.name
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-3xl tabular-nums",
						children: formatPrice(deal.amount)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs text-muted",
						children: formatDealNo(deal.publicNo)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 border border-ink/25",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: busy || deal.status !== "completed",
							className: deal.status !== "completed" ? "min-h-11 bg-wine text-foam" : "min-h-11 text-ink",
							onClick: () => void act(() => setDealOpen({ data: {
								id: deal.id,
								open: true
							} }), "Сделка открыта"),
							children: "Открыто"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: busy || deal.status === "completed",
							className: deal.status === "completed" ? "min-h-11 bg-wine text-foam" : "min-h-11 border-l border-ink/25 text-ink",
							onClick: () => void act(() => setDealOpen({ data: {
								id: deal.id,
								open: false
							} }), "Сделка закрыта"),
							children: "Закрыто"
						})]
					})
				]
			})
		})]
	});
}
//#endregion
export { DealPage as component };
