import { T as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/nick-BpIOwPBG.js
var import_jsx_runtime = require_jsx_runtime();
function Nick({ handle, premium = false, className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/u/$handle",
		params: { handle },
		className: `hover:underline ${className}`,
		children: [premium ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "star",
			"aria-hidden": "true",
			children: ["★", " "]
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: premium ? "text-[#e6c36a]" : void 0,
			children: ["@", handle]
		})]
	});
}
function PremiumBadge() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "border border-[#e6c36a] px-2 py-1 font-mono text-xs text-[#e6c36a]",
		children: "Premium"
	});
}
//#endregion
export { PremiumBadge as n, Nick as t };
