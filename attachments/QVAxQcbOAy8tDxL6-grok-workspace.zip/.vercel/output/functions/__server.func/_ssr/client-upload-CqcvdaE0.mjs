import { i as MAX_DIM, t as CHAT_IMAGE_DIM } from "./shared-Bel-W2Fu.mjs";
import { b as attachDealImage, rt as uploadMedia } from "./router-FBojnzgg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/client-upload-CqcvdaE0.js
function readB64(file) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => {
			const raw = String(reader.result ?? "");
			const cut = raw.indexOf(",");
			resolve(cut >= 0 ? raw.slice(cut + 1) : raw);
		};
		reader.onerror = () => reject(/* @__PURE__ */ new Error("Не удалось прочитать файл"));
		reader.readAsDataURL(file);
	});
}
async function canvasJpeg(file, edge, quality) {
	let bmp;
	try {
		bmp = await createImageBitmap(file);
	} catch {
		return null;
	}
	const scale = Math.min(1, edge / Math.max(bmp.width, bmp.height, 1));
	const width = Math.max(1, Math.round(bmp.width * scale));
	const height = Math.max(1, Math.round(bmp.height * scale));
	const canvas = document.createElement("canvas");
	canvas.width = width;
	canvas.height = height;
	const ctx = canvas.getContext("2d");
	if (!ctx) {
		bmp.close();
		return null;
	}
	ctx.fillStyle = "#131211";
	ctx.fillRect(0, 0, width, height);
	ctx.drawImage(bmp, 0, 0, width, height);
	bmp.close();
	return new Promise((resolve) => canvas.toBlob((blob) => resolve(blob), "image/jpeg", quality));
}
/** Reject a preview before a lot exists. Throws instead of uploading. */
async function checkPreviewFile(file) {
	if (file.size > 4194304) throw new Error(`«${file.name}» больше 4 МБ`);
	if (file.size < 32) throw new Error("Файл пустой");
	if (file.type && !file.type.startsWith("image/")) throw new Error("Превью — только PNG, JPG, WEBP или GIF");
	let bmp;
	try {
		bmp = await createImageBitmap(file);
	} catch {
		throw new Error("Превью — только PNG, JPG, WEBP или GIF");
	}
	const { width, height } = bmp;
	bmp.close();
	if (width > 4e3 || height > 4e3) throw new Error(`«${file.name}» больше ${MAX_DIM}×${MAX_DIM}`);
}
/** Chat pictures stay original: no canvas, no recompress. */
async function checkChatImage(file) {
	if (file.size > 3145728) throw new Error(`«${file.name}» больше 3 МБ`);
	if (file.size < 32) throw new Error("Файл пустой");
	if (file.type && !file.type.startsWith("image/")) throw new Error("В чат — только PNG, JPG, WEBP или GIF");
	let bmp;
	try {
		bmp = await createImageBitmap(file);
	} catch {
		throw new Error("В чат — только PNG, JPG, WEBP или GIF");
	}
	const { width, height } = bmp;
	bmp.close();
	if (width > 3e3 || height > 3e3) throw new Error(`«${file.name}» больше ${CHAT_IMAGE_DIM}×${CHAT_IMAGE_DIM}`);
}
async function pushChatImage(messageId, file) {
	await checkChatImage(file);
	const b64 = await readB64(file);
	if (b64.length < 32) throw new Error("Не удалось прочитать файл");
	await attachDealImage({ data: {
		messageId,
		filename: file.name,
		b64
	} });
}
async function pushFile(listingId, file, kind) {
	if (kind !== "preview") {
		if (file.size > 4194304) throw new Error(`«${file.name}» больше 4 МБ`);
		if (file.size < 32) throw new Error("Файл пустой");
		throw new Error("Полные файлы через площадку больше не принимаются");
	}
	await checkPreviewFile(file);
	const card = await canvasJpeg(file, 640, .64);
	const view = file.type === "image/gif" && file.size <= 7e5 ? file : await canvasJpeg(file, 1200, .72) ?? file;
	const [b64, cardB64] = await Promise.all([readB64(view), card ? readB64(card) : Promise.resolve(null)]);
	if (b64.length < 32) throw new Error("Не удалось прочитать файл");
	await uploadMedia({ data: {
		listingId,
		kind,
		filename: view instanceof File ? view.name : file.name.replace(/\.\w+$/, "") + ".jpg",
		b64,
		cardB64
	} });
}
//#endregion
export { pushFile as i, checkPreviewFile as n, pushChatImage as r, checkChatImage as t };
