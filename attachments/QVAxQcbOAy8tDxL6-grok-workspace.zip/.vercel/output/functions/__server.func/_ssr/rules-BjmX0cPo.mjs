import { T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as Kicker } from "./ui-bits-BXR9txbf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/rules-BjmX0cPo.js
var import_jsx_runtime = require_jsx_runtime();
var RULES = [
	{
		title: "Конфликты",
		lines: ["Не создавайте конфликтные ситуации и не участвуйте в них."]
	},
	{
		title: "Права на персонажа",
		lines: [
			"Публиковать можно только то, на что у вас есть право: собственные работы или персонажи с подтверждением создания/покупки.",
			"Нельзя плагиатить, копировать чужие работы и присваивать уже существующих персонажей.",
			"Нельзя публиковаться от лица других людей."
		]
	},
	{
		title: "Доказательства",
		lines: ["При публикации лота у вас должны быть пруфы создания или приобретения персонажа. По запросу модерации их нужно предоставить."]
	},
	{
		title: "Оплата и условия",
		lines: ["В лоте или в чате сделки вы обязаны указать, куда идёт оплата и какие правила действуют на персонажа."]
	},
	{
		title: "Контент 18+",
		lines: [
			"Запрещены изображения 18+. В описании можно кратко упоминать тематику.",
			"Лёгкая эротика допустима.",
			"Жёсткий 18+ — нет."
		]
	},
	{
		title: "Запрещённый контент",
		lines: ["Запрещены материалы, связанные с селфхармом, гуро, эксплуатацией несовершеннолетних и аналогичным контентом."]
	},
	{
		title: "Спам",
		lines: ["Нельзя публиковать одинаковые или почти одинаковые записи. Одновременно у автора может быть только одна актуальная запись по одному и тому же персонажу/лоту.", "Кастомы не идут в счёт."]
	},
	{
		title: "Баны и фейки",
		lines: ["Если аккаунт получил бан на сайте, создавать новые аккаунты запрещено."]
	},
	{
		title: "Жалобы",
		lines: [
			"При нарушении правил напишите в личные сообщения модерации/администрации и приложите описание, ссылки или скриншоты.",
			"Под постами аукционов и фиксов можно оставлять жалобы. Их видит только администрация сайта.",
			"При нарушении лот могут снять, аккаунт — ограничить или забанить."
		]
	}
];
function RulesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-2xl space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "house rules" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-2 font-display text-5xl leading-none",
			children: "правила"
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "space-y-4",
			children: RULES.map((rule, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "border-t border-ink/15 pt-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs text-muted",
						children: String(i + 1).padStart(2, "0")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: rule.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 space-y-2 text-muted",
						children: rule.lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: line }, line))
					})
				]
			}, rule.title))
		})]
	});
}
//#endregion
export { RulesPage as component };
