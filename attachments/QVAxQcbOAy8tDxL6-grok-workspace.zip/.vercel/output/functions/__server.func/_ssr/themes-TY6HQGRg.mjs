import { n as createMiddleware } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/themes-TY6HQGRg.js
/**
* Auth middleware for server functions — the standard way to get the caller's
* verified user id. When deployed the session cookie is same-origin and rides
* along automatically. In the live preview the client also forwards the bearer
* token (partitioned cookies) via the `.client` hook below — call sites do not
* thread it themselves.
*
*   import { createServerFn } from "@tanstack/react-start";
*   import { getSql } from "@/lib/db";
*   import { authMiddleware } from "@/lib/auth/middleware";
*
*   export const listTodos = createServerFn({ method: "GET" })
*     .middleware([authMiddleware])
*     .handler(async ({ context }) => {
*       const sql = await getSql();
*       return sql`select * from todos where user_id = ${context.userId}`;
*     });
*
* Signed out with auth on (live preview included) -> throws `UnauthorizedError`
* (see `verify.server.ts`). With auth disabled (`VITE_AUTH_ENABLED=false`, the
* shipped default) it resolves the shared dev user — but throws instead when a
* `DATABASE_URL` is also set, so an app without sign-in must not use this at
* all. On the auth-on path, use it on every server function that touches
* per-user data and scope every query by `context.userId`.
*/
var authMiddleware = createMiddleware({ type: "function" }).client(async ({ next }) => {
	const { getBearerToken } = await import("./client-BDq8GlIC.mjs").then((n) => n.n);
	return next({ sendContext: { bearerToken: getBearerToken() ?? void 0 } });
}).server(async ({ next, context }) => {
	const { assertSameSiteRequest } = await import("./isolation.server-CGNg1r0B.mjs");
	const { requireUserId } = await import("./verify.server-BE9fQtNc.mjs");
	assertSameSiteRequest();
	return next({ context: { userId: await requireUserId(context.bearerToken) } });
});
/** Session if present, null if signed out. Still blocks scripted cross-site calls. */
var optionalAuth = createMiddleware({ type: "function" }).client(async ({ next }) => {
	const { getBearerToken } = await import("./client-BDq8GlIC.mjs").then((n) => n.n);
	return next({ sendContext: { bearerToken: getBearerToken() ?? void 0 } });
}).server(async ({ next, context }) => {
	const { assertSameSiteRequest } = await import("./isolation.server-CGNg1r0B.mjs");
	const { getSessionUser } = await import("./verify.server-BE9fQtNc.mjs");
	assertSameSiteRequest();
	return next({ context: { userId: (await getSessionUser(context.bearerToken))?.id ?? null } });
});
var THEME_IDS = [
	"classic",
	"gold",
	"midnight",
	"pastel",
	"forest",
	"ice",
	"paper",
	"neon",
	"gallery",
	"terminal",
	"light"
];
var THEMES = {
	classic: {
		id: "classic",
		label: "Classic",
		bg: "#131211",
		ink: "#f3ece4",
		muted: "#a39890",
		card: "#1c1a18",
		accent: "#8B2E4A",
		line: "rgba(243,236,228,0.2)",
		foam: "#f6f1ea"
	},
	gold: {
		id: "gold",
		label: "Gold Premium",
		bg: "#16120c",
		ink: "#f6edd8",
		muted: "#c6b48a",
		card: "#241c12",
		accent: "#e6c36a",
		line: "rgba(230,195,106,0.35)",
		foam: "#1a1408"
	},
	midnight: {
		id: "midnight",
		label: "Midnight",
		bg: "#0c1020",
		ink: "#e7ebff",
		muted: "#9aa3c7",
		card: "#151a30",
		accent: "#7d8cff",
		line: "rgba(231,235,255,0.18)",
		foam: "#f4f6ff"
	},
	pastel: {
		id: "pastel",
		label: "Soft Pastel",
		bg: "#f6efe8",
		ink: "#3a2c32",
		muted: "#8d7380",
		card: "#fff8f4",
		accent: "#d4899a",
		line: "rgba(58,44,50,0.16)",
		foam: "#fffaf7"
	},
	forest: {
		id: "forest",
		label: "Forest",
		bg: "#101612",
		ink: "#e7f3ea",
		muted: "#9bb5a2",
		card: "#18211b",
		accent: "#6faf7a",
		line: "rgba(231,243,234,0.18)",
		foam: "#f3fff5"
	},
	ice: {
		id: "ice",
		label: "Ice",
		bg: "#eef3f6",
		ink: "#1a242c",
		muted: "#5d7382",
		card: "#f7fbfd",
		accent: "#3d7ea6",
		line: "rgba(26,36,44,0.16)",
		foam: "#f4fbff"
	},
	paper: {
		id: "paper",
		label: "Paper",
		bg: "#f3efe6",
		ink: "#1a1614",
		muted: "#6e655e",
		card: "#faf7f1",
		accent: "#8B2E4A",
		line: "rgba(26,22,20,0.16)",
		foam: "#fffdf8"
	},
	neon: {
		id: "neon",
		label: "Neon",
		bg: "#0e0e12",
		ink: "#f4ffe8",
		muted: "#b7c9a4",
		card: "#17171e",
		accent: "#d4ff4a",
		line: "rgba(212,255,74,0.28)",
		foam: "#101208"
	},
	gallery: {
		id: "gallery",
		label: "Gallery",
		bg: "#181614",
		ink: "#f4efe6",
		muted: "#b7aea4",
		card: "#221f1c",
		accent: "#efe6d6",
		line: "rgba(244,239,230,0.2)",
		foam: "#1a1816"
	},
	terminal: {
		id: "terminal",
		label: "Retro Terminal",
		bg: "#0a120c",
		ink: "#b6ff9a",
		muted: "#6d9a62",
		card: "#0f1a12",
		accent: "#39ff14",
		line: "rgba(57,255,20,0.28)",
		foam: "#041006"
	},
	light: {
		id: "light",
		label: "Light",
		bg: "#f7f4ef",
		ink: "#1a1614",
		muted: "#6d6560",
		card: "#fffdf9",
		accent: "#6B1E3A",
		line: "rgba(26,22,20,0.14)",
		foam: "#fffaf6"
	}
};
var ACCENT_IDS = [
	"wine",
	"gold",
	"rose",
	"ice",
	"forest",
	"violet",
	"ember",
	"ink"
];
var ACCENTS = {
	wine: {
		label: "Вино",
		color: "#8B2E4A"
	},
	gold: {
		label: "Золото",
		color: "#e6c36a"
	},
	rose: {
		label: "Роза",
		color: "#d47a8c"
	},
	ice: {
		label: "Лёд",
		color: "#7eb6d6"
	},
	forest: {
		label: "Лес",
		color: "#6faf7a"
	},
	violet: {
		label: "Фиолет",
		color: "#8a6bb5"
	},
	ember: {
		label: "Уголь",
		color: "#d4654a"
	},
	ink: {
		label: "Светлый",
		color: "#e8e0d4"
	}
};
var FRAME_IDS = [
	"thin",
	"circle",
	"rounded",
	"gold",
	"none"
];
var FRAME_LABELS = {
	thin: "Тонкая",
	circle: "Круг",
	rounded: "Скруглённый квадрат",
	gold: "Золотая",
	none: "Без рамки"
};
var OVERLAY_IDS = [
	"gradient",
	"darken",
	"vignette",
	"none"
];
var OVERLAY_LABELS = {
	gradient: "Градиент",
	darken: "Затемнение",
	vignette: "Виньетка",
	none: "Без оверлея"
};
function asTheme(value) {
	return THEME_IDS.includes(value) ? value : "classic";
}
function asAccent(value) {
	return ACCENT_IDS.includes(value) ? value : "wine";
}
function asFrame(value) {
	return FRAME_IDS.includes(value) ? value : "thin";
}
function asOverlay(value) {
	return OVERLAY_IDS.includes(value) ? value : "gradient";
}
function premiumActive(forever, until, now = Date.now()) {
	if (forever) return true;
	if (!until) return false;
	const time = new Date(until).getTime();
	return Number.isFinite(time) && time > now;
}
//#endregion
export { OVERLAY_IDS as a, THEME_IDS as c, asOverlay as d, asTheme as f, premiumActive as h, FRAME_LABELS as i, asAccent as l, optionalAuth as m, ACCENT_IDS as n, OVERLAY_LABELS as o, authMiddleware as p, FRAME_IDS as r, THEMES as s, ACCENTS as t, asFrame as u };
