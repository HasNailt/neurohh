import { o as __toESM } from "../_runtime.mjs";
import { v as formatLeft, y as formatPrice } from "./shared-Bel-W2Fu.mjs";
import { $ as require_react, T as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Frame } from "./ui-bits-BXR9txbf.mjs";
import { t as PreviewImg } from "./preview-img-0tbn4PG-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/listing-card-Ds-TmwB_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LiveLeft({ endsAt }) {
	const [text, setText] = (0, import_react.useState)("···");
	(0, import_react.useEffect)(() => {
		const tick = () => setText(formatLeft(endsAt));
		tick();
		const id = window.setInterval(tick, 1e3);
		return () => window.clearInterval(id);
	}, [endsAt]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "tabular-nums",
		children: text
	});
}
function ListingCardView({ item, showPrice = true, dense = false }) {
	const price = item.kind === "auction" ? item.currentBid ?? item.price : item.price;
	const letter = (item.title.trim()[0] || "A").toLocaleUpperCase("ru");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
		className: "min-w-0",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/lot/$id",
			params: { id: item.id },
			className: "block",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, {
				gold: item.sellerPremium,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "poster relative overflow-hidden bg-soft",
					children: [
						item.previewId || item.previewSrc ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewImg, {
							id: item.previewId,
							src: item.previewSrc,
							alt: "",
							className: "h-full w-full object-cover",
							fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid h-full place-items-center bg-wine-deep",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: dense ? "font-display text-4xl leading-none text-foam" : "font-display text-7xl leading-none text-foam",
									children: letter
								})
							})
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid h-full place-items-center bg-wine-deep",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: dense ? "font-display text-4xl leading-none text-foam" : "font-display text-7xl leading-none text-foam",
								children: letter
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute top-2 left-2 flex gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "border border-ink/20 bg-paper/85 px-1.5 py-0.5 font-mono text-[10px]",
									children: [item.kind === "auction" ? "AUC" : "FIX", item.pinned ? " · PIN" : ""]
								}),
								item.sellerPremium ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "border border-[#e6c36a] bg-[#1a1408]/85 px-1.5 py-0.5 font-mono text-[10px] text-[#e6c36a]",
									children: "★"
								}) : null,
								item.boosted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "bg-[#e6c36a] px-1.5 py-0.5 font-mono text-[10px] text-[#1a1408]",
									children: "BOOST"
								}) : null
							]
						}),
						item.kind === "auction" && item.endsAt && item.status === "active" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute top-2 right-2 bg-wine px-1.5 py-0.5 font-mono text-[10px] text-foam",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveLeft, { endsAt: item.endsAt })
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute inset-x-0 bottom-0 bg-gradient-to-t from-paper via-paper/95 to-transparent px-2 pt-10 pb-2 text-ink",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: dense ? "truncate font-display text-sm leading-none" : "truncate font-display text-xl leading-none",
									children: item.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 truncate font-mono text-[11px]",
									children: [item.sellerPremium ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "star",
										children: "★ "
									}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: item.sellerPremium ? "text-[#e6c36a]" : "text-muted",
										children: ["@", item.sellerHandle]
									})]
								}),
								showPrice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: dense ? "mt-1 font-display text-base tabular-nums leading-none" : "mt-1 font-display text-lg tabular-nums leading-none",
									children: formatPrice(price)
								}) : null,
								item.kind === "auction" && item.bidCount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-mono text-[11px] text-muted",
									children: [item.bidCount, " став."]
								}) : null
							]
						})
					]
				})
			})
		})
	});
}
//#endregion
export { ListingCardView as t };
