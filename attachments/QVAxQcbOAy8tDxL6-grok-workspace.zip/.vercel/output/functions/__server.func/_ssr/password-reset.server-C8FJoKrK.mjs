import { o as __toESM } from "../_runtime.mjs";
import { o as getRequest } from "./ssr.mjs";
import { t as SITE_ORIGIN } from "./site-CxOwa5sg.mjs";
import { a as getSql } from "./db-B6SjOW4g.mjs";
import { i as persistentDatabaseMissing, r as hashPassword, t as DB_UNAVAILABLE } from "./credential-store.server-2PDrlSX-.mjs";
import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
//#region node_modules/.nitro/vite/services/ssr/assets/password-reset.server-C8FJoKrK.js
var RESEND_GAP_MS = 6e4;
function mailConfig() {
	const from = process.env.EMAIL_FROM?.trim() || "";
	const resend = process.env.RESEND_API_KEY?.trim() || "";
	if (resend && from) return {
		kind: "resend",
		key: resend,
		from
	};
	const host = process.env.SMTP_HOST?.trim() || "";
	const user = process.env.SMTP_USER?.trim() || "";
	const pass = process.env.SMTP_PASS?.trim() || "";
	const port = Number(process.env.SMTP_PORT || 587);
	const secure = process.env.SMTP_SECURE === "1" || port === 465;
	if (host && user && pass && (from || user)) return {
		kind: "smtp",
		host,
		port,
		secure,
		user,
		pass,
		from: from || user
	};
	return null;
}
function origin() {
	try {
		const req = getRequest();
		const host = (req.headers.get("x-forwarded-host") || req.headers.get("host") || "").split(",")[0]?.trim() || "";
		const proto = (req.headers.get("x-forwarded-proto") || "https").split(",")[0]?.trim() || "https";
		if (host === "neurohh.ru" || host === "www.neurohh.ru") return SITE_ORIGIN;
		if (host.endsWith(".vercel.app") || host.startsWith("localhost") || host.startsWith("127.0.0.1")) return `${proto}://${host}`;
	} catch {}
	return SITE_ORIGIN;
}
async function deliver(to, url) {
	const mail = mailConfig();
	if (!mail) throw new Error("Почта не настроена");
	const subject = "Сброс пароля AdoptAI";
	const text = [
		"Чтобы задать новый пароль, откройте ссылку.",
		"Она действует 1 час и только один раз.",
		"",
		url,
		"",
		"Если вы не запрашивали сброс, ничего делать не нужно."
	].join("\n");
	if (mail.kind === "resend") {
		if (!(await fetch("https://api.resend.com/emails", {
			method: "POST",
			headers: {
				Authorization: `Bearer ${mail.key}`,
				"Content-Type": "application/json"
			},
			body: JSON.stringify({
				from: mail.from,
				to: [to],
				subject,
				text
			})
		})).ok) throw new Error("Не удалось отправить письмо");
		return;
	}
	await (await import("../_libs/nodemailer.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()))).createTransport({
		host: mail.host,
		port: mail.port,
		secure: mail.secure,
		auth: {
			user: mail.user,
			pass: mail.pass
		}
	}).sendMail({
		from: mail.from,
		to,
		subject,
		text
	});
}
function tokenHash(token) {
	return createHash("sha256").update(token).digest("hex");
}
function sameHash(a, b) {
	const left = Buffer.from(a);
	const right = Buffer.from(b);
	return left.length === right.length && timingSafeEqual(left, right);
}
async function requestPasswordResetEmail(email) {
	if (persistentDatabaseMissing()) return {
		ok: false,
		message: DB_UNAVAILABLE
	};
	if (!mailConfig()) return {
		ok: false,
		message: "Отправка писем не настроена. Добавьте SMTP или Resend в переменные окружения."
	};
	const sql = await getSql();
	const user = (await sql`
    select id from "user" where lower(email) = ${email} limit 1
  `)[0];
	if (!user) return { ok: true };
	const identifier = `password-reset:${user.id}`;
	const recent = await sql`
    select "createdAt" as created_at
    from verification
    where identifier = ${identifier} and "expiresAt" > now()
    order by "createdAt" desc
    limit 1
  `;
	const created = recent[0]?.created_at ? new Date(recent[0].created_at).getTime() : 0;
	if (created && Date.now() - created < RESEND_GAP_MS) return { ok: true };
	const token = randomBytes(32).toString("hex");
	const id = randomBytes(16).toString("hex");
	await sql`delete from verification where identifier = ${identifier}`;
	await sql`
    insert into verification (id, identifier, value, "expiresAt", "createdAt", "updatedAt")
    values (
      ${id},
      ${identifier},
      ${tokenHash(token)},
      now() + interval '1 hour',
      now(),
      now()
    )
  `;
	try {
		await deliver(email, `${origin()}/reset-password?token=${token}`);
	} catch {
		await sql`delete from verification where id = ${id}`;
		return {
			ok: false,
			message: "Не удалось отправить письмо. Проверьте настройки почты."
		};
	}
	return { ok: true };
}
async function applyPasswordReset(token, password) {
	if (persistentDatabaseMissing()) return {
		ok: false,
		message: DB_UNAVAILABLE
	};
	const sql = await getSql();
	const hash = tokenHash(token);
	const row = (await sql`
    select id, identifier, value, "expiresAt" as expires_at
    from verification
    where identifier like 'password-reset:%' and value = ${hash}
    limit 1
  `)[0];
	if (!row || !sameHash(row.value, hash) || new Date(row.expires_at).getTime() <= Date.now()) return {
		ok: false,
		message: "Ссылка недействительна или уже использована. Запросите новую."
	};
	const userId = row.identifier.slice(15);
	if (!userId) return {
		ok: false,
		message: "Ссылка недействительна или уже использована. Запросите новую."
	};
	const passwordHash = await hashPassword(password);
	if (!(await sql`
    update account
    set password = ${passwordHash}, "updatedAt" = now()
    where "userId" = ${userId} and "providerId" = 'credential'
    returning id
  `)[0]) await sql`
      insert into account (id, "accountId", "providerId", "userId", password, "createdAt", "updatedAt")
      values (${randomBytes(16).toString("hex")}, ${userId}, 'credential', ${userId}, ${passwordHash}, now(), now())
    `;
	await sql`delete from "session" where "userId" = ${userId}`;
	await sql`delete from verification where identifier = ${row.identifier}`;
	return { ok: true };
}
//#endregion
export { applyPasswordReset, requestPasswordResetEmail };
