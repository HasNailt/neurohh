import { o as __toESM } from "../_runtime.mjs";
import { b as formatWhen, g as errText } from "./shared-Bel-W2Fu.mjs";
import { $ as require_react, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { O as deletePost, X as setPostPinned, _ as addPostComment } from "./router-FBojnzgg.mjs";
import { a as fieldClass, t as Button } from "./ui-bits-BXR9txbf.mjs";
import { t as EmojiBar } from "./emoji-bar-CCnR6UyB.mjs";
import { n as PremiumBadge, t as Nick } from "./nick-BpIOwPBG.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/post-card-FTsekDbH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PostCard({ post, mine, onChange }) {
	const [body, setBody] = (0, import_react.useState)("");
	const [replyTo, setReplyTo] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const roots = post.comments.filter((comment) => !comment.parentId);
	const replies = (id) => post.comments.filter((comment) => comment.parentId === id);
	function send(parentId) {
		const text = body.trim();
		if (!text) return;
		setBusy(true);
		addPostComment({ data: {
			postId: post.id,
			parentId,
			body: text
		} }).then(() => {
			setBody("");
			setReplyTo(null);
			onChange();
		}).catch((err) => toast.error(errText(err))).finally(() => setBusy(false));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: post.authorPremium ? "space-y-4 border border-[#e6c36a] bg-card p-5 sm:p-6" : "space-y-4 border border-ink/20 bg-card p-5 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-mono text-xs text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nick, {
							handle: post.authorHandle,
							premium: post.authorPremium
						}),
						post.authorPremium ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PremiumBadge, {})
						}) : null,
						post.authorIsNew ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-2 border border-ink/30 px-2 py-0.5",
							children: "Новый пользователь"
						}) : null,
						post.pinned ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-2 border border-[#e6c36a] px-2 py-0.5 text-[#e6c36a]",
							children: "PIN"
						}) : null,
						" · ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							suppressHydrationWarning: true,
							children: formatWhen(post.createdAt)
						})
					]
				}), mine ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "font-mono text-xs text-muted hover:text-ink",
						onClick: () => {
							setPostPinned({ data: {
								id: post.id,
								pinned: !post.pinned
							} }).then(onChange).catch((err) => toast.error(errText(err)));
						},
						children: post.pinned ? "Открепить" : "Закрепить"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "font-mono text-xs text-muted hover:text-ink",
						onClick: () => {
							if (!window.confirm("Удалить пост? Он исчезнет вместе с картинками и комментариями.")) return;
							deletePost({ data: post.id }).then(onChange).catch((err) => toast.error(errText(err)));
						},
						children: "Удалить"
					})]
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "whitespace-pre-wrap",
				children: post.body
			}),
			post.images.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap items-start gap-3",
				children: post.images.map((image) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: image.src,
					alt: "",
					className: "h-auto max-h-[28rem] w-auto max-w-full object-contain"
				}, image.id))
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-3 border-t border-ink/10 pt-3",
				children: roots.map((comment) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommentLine, {
					comment,
					onReply: () => setReplyTo(comment.id)
				}), replies(comment.id).length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 space-y-2 border-l border-ink/15 pl-3",
					children: replies(comment.id).map((reply) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommentLine, {
						comment: reply,
						onReply: () => setReplyTo(comment.id)
					}) }, reply.id))
				}) : null] }, comment.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex items-center gap-2",
				onSubmit: (e) => {
					e.preventDefault();
					send(replyTo);
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmojiBar, {
						up: true,
						onPick: (emoji) => setBody((value) => value + emoji)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: body,
						onChange: (e) => setBody(e.target.value),
						placeholder: replyTo ? "Ответ" : "Комментарий",
						className: `${fieldClass} min-w-0 flex-1`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						variant: "line",
						disabled: busy,
						children: "ок"
					})
				]
			})
		]
	});
}
function CommentLine({ comment, onReply }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "font-mono text-xs text-muted",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nick, {
				handle: comment.authorHandle,
				premium: comment.authorPremium
			}),
			" · ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				suppressHydrationWarning: true,
				children: formatWhen(comment.createdAt)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "ml-2 underline",
				onClick: onReply,
				children: "ответить"
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "whitespace-pre-wrap",
		children: comment.body
	})] });
}
//#endregion
export { PostCard as t };
