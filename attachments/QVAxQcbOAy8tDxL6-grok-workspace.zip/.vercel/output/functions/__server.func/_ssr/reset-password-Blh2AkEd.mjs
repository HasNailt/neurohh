import { o as __toESM } from "../_runtime.mjs";
import { $ as require_react, T as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as Route$13 } from "./router-FBojnzgg.mjs";
import { a as fieldClass, r as Kicker, t as Button } from "./ui-bits-BXR9txbf.mjs";
import { n as resetPassword } from "./password-reset-D_HEmNd0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reset-password-Blh2AkEd.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ResetPage() {
	const { token } = Route$13.useSearch();
	const [password, setPassword] = (0, import_react.useState)("");
	const [again, setAgain] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [done, setDone] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function onSubmit(e) {
		e.preventDefault();
		setError(null);
		if (password !== again) {
			setError("Пароли не совпадают");
			return;
		}
		setBusy(true);
		try {
			const res = await resetPassword({ data: {
				token,
				password
			} });
			if (!res.ok) {
				setError(res.message);
				setBusy(false);
				return;
			}
			setDone(true);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Не получилось");
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-md gap-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "new key" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-2 font-display text-5xl leading-none",
			children: "новый пароль"
		})] }), !token ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "В ссылке нет кода. Запросите сброс ещё раз." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/forgot",
				className: "inline-flex text-sm underline",
				children: "Запросить ссылку"
			})]
		}) : done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3 border border-ink/20 bg-card p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Пароль обновлён. Войдите с новым паролем." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/login",
				className: "inline-flex text-sm underline",
				children: "Ко входу"
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: (e) => void onSubmit(e),
			className: "space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm",
					children: ["Новый пароль", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "password",
						required: true,
						minLength: 8,
						maxLength: 128,
						value: password,
						onChange: (e) => setPassword(e.target.value),
						autoComplete: "new-password",
						className: `${fieldClass} mt-1`
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm",
					children: ["Ещё раз", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "password",
						required: true,
						minLength: 8,
						maxLength: 128,
						value: again,
						onChange: (e) => setAgain(e.target.value),
						autoComplete: "new-password",
						className: `${fieldClass} mt-1`
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: "Минимум 8 символов. Ссылка сгорит после сохранения."
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					variant: "wine",
					disabled: busy,
					className: "w-full",
					children: busy ? "Сохраняем…" : "Сохранить пароль"
				})
			]
		})]
	});
}
//#endregion
export { ResetPage as component };
