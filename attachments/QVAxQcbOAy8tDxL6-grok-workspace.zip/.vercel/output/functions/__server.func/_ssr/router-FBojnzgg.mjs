import { o as __toESM } from "../_runtime.mjs";
import { E as parsePrice, S as isStaff, T as parseFeedQuery, a as PREMIUM_BLURB_MAX, b as formatWhen, c as UUID_RE, d as asRole, f as asStatus, g as errText, l as asBadges, m as cleanHandle, s as SNIPE_OPTIONS } from "./shared-Bel-W2Fu.mjs";
import { t as __exportAll } from "./rolldown-runtime-D7D4PA-g.mjs";
import { $ as require_react, C as useNavigate, T as require_jsx_runtime, X as redirect, _ as Outlet, b as createRootRoute, f as Scripts, g as createRouter, m as useRouterState, n as require_react_dom, p as HeadContent, v as lazyRouteComponent, x as Link, y as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { d as asOverlay, f as asTheme, l as asAccent, m as optionalAuth, p as authMiddleware, u as asFrame } from "./themes-TY6HQGRg.mjs";
import { a as signOut, t as authClient } from "./client-BDq8GlIC.mjs";
import { t as SITE_ORIGIN } from "./site-CxOwa5sg.mjs";
import { i as hasGateSessionMarker, t as auth } from "./server-D0fyK5tr.mjs";
import { a as Plus, i as Search, n as TriangleAlert, o as Moon, r as Sun, s as Bell, t as X } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/createSsrRpc-B2Izd0c7.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/server-gYvMv4JP.js
function cleanText(s, max) {
	const cleaned = s.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "").trim();
	return Array.from(cleaned).slice(0, max).join("");
}
function fail(message) {
	throw new Error(message);
}
var listListings = createServerFn({ method: "GET" }).middleware([optionalAuth]).validator((input) => parseFeedQuery(input)).handler(createSsrRpc("b6a7d5fa941a65f1e9a29197e264e8903e8885fcb9c2f3769a8c3521e9c927bd"));
var listPopularTags = createServerFn({ method: "GET" }).handler(createSsrRpc("e37e03903636af950f708b1749e1e77323c97006701b22cbc0c719143a338ed1"));
var searchPeople = createServerFn({ method: "GET" }).validator((q) => typeof q === "string" ? q.trim().replace(/^@+/, "").slice(0, 40) : "").handler(createSsrRpc("79f847d91652e111534e63e3a4162491fea229acc8bb12df70ef67b0d7acef84"));
var suggestTags = createServerFn({ method: "GET" }).validator((q) => typeof q === "string" ? q : "").handler(createSsrRpc("56767778d629385039aedf4b7bdf2a4cacdc81e0392c97a9df19ce510b0c285b"));
var getListing = createServerFn({ method: "GET" }).middleware([optionalAuth]).validator((id) => {
	if (typeof id !== "string" || !UUID_RE.test(id)) fail("Некорректный лот");
	return id;
}).handler(createSsrRpc("bda47970204a80cb81982959abc9a9b148110d753a4429f41b0860710fb78fd8"));
function parseCreate(input) {
	if (!input || typeof input !== "object") fail("Пустая форма");
	const o = input;
	const title = cleanText(typeof o.title === "string" ? o.title : "", 80);
	const blurb = cleanText(typeof o.blurb === "string" ? o.blurb : "", PREMIUM_BLURB_MAX);
	const privateDescription = cleanText(typeof o.privateDescription === "string" ? o.privateDescription : "", 8e3);
	if (title.length < 3) fail("Название — хотя бы 3 символа");
	const kind = o.kind === "auction" ? "auction" : o.kind === "fixed" ? "fixed" : null;
	if (!kind) fail("Выберите аукцион или фиксированную цену");
	const price = parsePrice(o.price);
	if (price == null) fail("Цена — целое число от 1");
	let buyNow = null;
	if (kind === "auction" && o.buyNow != null && o.buyNow !== "") {
		buyNow = parsePrice(o.buyNow);
		if (buyNow == null || buyNow <= price) fail("«Купить сейчас» должно быть выше стартовой цены");
	}
	const durationHours = Number(o.durationHours);
	if (kind === "auction" && ![
		1,
		6,
		12,
		24,
		72,
		168
	].includes(durationHours)) fail("Выберите длительность аукциона");
	const anti = Number(o.antiSnipeMinutes);
	if (kind === "auction" && !SNIPE_OPTIONS.includes(anti)) fail("Выберите антиснайп: выключить, 10 минут, 30 минут или 1 час");
	const tags = Array.isArray(o.tags) ? o.tags.filter((t) => typeof t === "string") : [];
	if (tags.length > 8) fail("Не больше 8 тегов");
	return {
		title,
		blurb,
		privateDescription,
		kind,
		price,
		buyNow,
		durationHours: kind === "auction" ? durationHours : 0,
		antiSnipeMinutes: kind === "auction" ? anti : 3,
		tags
	};
}
var createListing = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator(parseCreate).handler(createSsrRpc("d4778423fe1e20b569530ff94ff79a175756576f472eac85cd282a23d954012c"));
/** A draft stays hidden until it has a cover. No cover — the lot is deleted. */
var publishListing = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => {
	if (typeof id !== "string" || !UUID_RE.test(id)) fail("Некорректный лот");
	return id;
}).handler(createSsrRpc("d37aede1eaad2b78882ba155976fd22c0ddd486113b686fca71ee830996fb741"));
function parseUpload(input) {
	if (!input || typeof input !== "object") fail("Пустой файл");
	const o = input;
	if (typeof o.listingId !== "string" || !UUID_RE.test(o.listingId)) fail("Некорректный лот");
	if (o.kind !== "preview") fail("Полные файлы через площадку больше не принимаются");
	if (typeof o.filename !== "string" || typeof o.b64 !== "string") fail("Файл не прочитан");
	if (o.b64.length > 12e6) fail("Файл больше 4 МБ");
	let cardB64 = null;
	if (typeof o.cardB64 === "string") {
		const cleaned = o.cardB64.replace(/^data:[^,]*,/, "").replace(/\s/g, "");
		if (cleaned.length > 80 && cleaned.length < 7e5) cardB64 = cleaned;
	}
	return {
		listingId: o.listingId,
		kind: o.kind,
		filename: o.filename,
		b64: o.b64.replace(/^data:[^,]*,/, "").replace(/\s/g, ""),
		cardB64
	};
}
var imageData = createServerFn({ method: "POST" }).validator((input) => {
	if (!input || typeof input !== "object") fail("Нет изображения");
	const id = input.id;
	const variant = input.variant;
	if (typeof id !== "string" || !UUID_RE.test(id)) fail("Некорректный файл");
	return {
		id,
		variant: variant === "view" ? "view" : "card"
	};
}).handler(createSsrRpc("18367d2430285aa5e747a4ac170df95da0e497581e79187974bc1447898e8654"));
var uploadMedia = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator(parseUpload).handler(createSsrRpc("3c04f445076c94152ff8ecde25d59a8f75469b3fb769350e5bac090d62ed247f"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => {
	if (typeof id !== "string" || !UUID_RE.test(id)) fail("Некорректный файл");
	return id;
}).handler(createSsrRpc("6be05f198e5243be78759153cd8238aa221512c9830515b4fde7861afb228ae5"));
function parseCopy(input) {
	if (!input || typeof input !== "object") fail("Пустая форма");
	const o = input;
	if (typeof o.id !== "string" || !UUID_RE.test(o.id)) fail("Некорректный лот");
	const title = cleanText(typeof o.title === "string" ? o.title : "", 80);
	const blurb = cleanText(typeof o.blurb === "string" ? o.blurb : "", PREMIUM_BLURB_MAX);
	if (title.length < 3) fail("Название — хотя бы 3 символа");
	const tags = Array.isArray(o.tags) ? o.tags.filter((t) => typeof t === "string").slice(0, 8) : [];
	return {
		id: o.id,
		title,
		blurb,
		tags
	};
}
var updateListingCopy = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator(parseCopy).handler(createSsrRpc("ef8da5247bebe9205aa96377c2d97ebb3b1fa9804e9e4492bb3003d27eb5bcf8"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => {
	if (typeof id !== "string" || !UUID_RE.test(id)) fail("Некорректный лот");
	return id;
}).handler(createSsrRpc("44aa51378a0677e4bcf838d30d8f6444965c3233606ca34e0e50690a362b5a4a"));
/** Erase a lot and everything attached to it: pictures, bids, chat, deal. */
/** Owner can erase any of their lots. Images, bids and the deal go with it. */
var deleteListing = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => {
	if (typeof id !== "string" || !UUID_RE.test(id)) fail("Некорректный лот");
	return id;
}).handler(createSsrRpc("8534a32c8a78a263b3b13ef78c93ed63296a2db37ae3615d2445d776a440028d"));
/** Drop a lot that was inserted but then failed image checks. Never leaves it active. */
var discardListing = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => {
	if (typeof id !== "string" || !UUID_RE.test(id)) fail("Некорректный лот");
	return id;
}).handler(createSsrRpc("182b4dfad731c9f53e355f459c4f278b0ce5b965be8d02875aabe89eb0ffcb38"));
var placeBid = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!input || typeof input !== "object") fail("Пустая ставка");
	const o = input;
	if (typeof o.listingId !== "string" || !UUID_RE.test(o.listingId)) fail("Некорректный лот");
	const amount = parsePrice(o.amount);
	if (amount == null) fail("Ставка — целое число");
	return {
		listingId: o.listingId,
		amount
	};
}).handler(createSsrRpc("19da62019141bc7a152f347a6a97e17f14e14e87a431f3d495f91df9d63b7dfd"));
var buyFixed = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => {
	if (typeof id !== "string" || !UUID_RE.test(id)) fail("Некорректный лот");
	return id;
}).handler(createSsrRpc("63b5b864df88484631b6b6674019351c41d639751a316b9944f011033c7948fc"));
var buyNow = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => {
	if (typeof id !== "string" || !UUID_RE.test(id)) fail("Некорректный лот");
	return id;
}).handler(createSsrRpc("46c6f899b470e984dc3ee7f7334df2a0b3c08b34491d7462682da7791e1ff265"));
var reportListing = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!input || typeof input !== "object") fail("Пустая жалоба");
	const o = input;
	if (typeof o.listingId !== "string" || !UUID_RE.test(o.listingId)) fail("Некорректный лот");
	const reason = cleanText(typeof o.reason === "string" ? o.reason : "", 500);
	if (reason.length < 4) fail("Опишите причину чуть подробнее");
	return {
		listingId: o.listingId,
		reason
	};
}).handler(createSsrRpc("fed956745cb2dd8f463b40bc9b76dab9390b7c6279aa6e3741236077403006f0"));
var getMe = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("6f0c9f686465c4ad6ccc78667dba70797b135a97859fe8fa06b5fb7a3affad54"));
function parseLinksInput(value) {
	if (value == null) return [];
	if (!Array.isArray(value)) fail("Ссылки указаны неверно");
	const out = [];
	for (const item of value.slice(0, 5)) {
		if (!item || typeof item !== "object") continue;
		const rec = item;
		const label = cleanText(typeof rec.label === "string" ? rec.label : "", 24);
		const url = cleanText(typeof rec.url === "string" ? rec.url : "", 200);
		if (!label && !url) continue;
		if (!label || !/^https?:\/\/\S+$/i.test(url)) fail("У каждой ссылки нужны подпись и адрес http(s)");
		out.push({
			label,
			url
		});
	}
	return out;
}
var updateProfile = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!input || typeof input !== "object") fail("Пустая форма");
	const o = input;
	const handle = cleanHandle(typeof o.handle === "string" ? o.handle : "");
	const displayName = cleanText(typeof o.displayName === "string" ? o.displayName : "", 40);
	const bio = cleanText(typeof o.bio === "string" ? o.bio : "", 400);
	const status = asStatus(o.status);
	if (o.status != null && ![
		"open",
		"busy",
		"closed",
		"away"
	].includes(String(o.status))) fail("Неизвестный статус");
	if (!handle) fail("Ник: 3–20 букв, цифр или _");
	if (displayName.length < 2) fail("Имя слишком короткое");
	return {
		handle,
		displayName,
		bio,
		status,
		links: parseLinksInput(o.links)
	};
}).handler(createSsrRpc("a5831a3909d9914f532f14668d505f75cdd9b9d265a4d5034350d62366abcf37"));
var getPublicProfile = createServerFn({ method: "GET" }).middleware([optionalAuth]).validator((input) => {
	const raw = typeof input === "string" ? {
		handle: input,
		page: 1
	} : input;
	if (!raw || typeof raw !== "object") fail("Некорректный профиль");
	const o = raw;
	const handle = typeof o.handle === "string" ? o.handle.trim().toLocaleLowerCase("ru") : "";
	if (!cleanHandle(handle)) fail("Некорректный профиль");
	const page = Number(o.page);
	return {
		handle,
		page: Number.isInteger(page) && page > 0 && page < 500 ? page : 1
	};
}).handler(createSsrRpc("af93279568551410cd06660a3f5aa6d72b6db81f51523afba7c29807a6c03378"));
var listDeals = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("ba141e203e074965d578de4b8c62735e3bfc7423a51daefffadf33450555158e"));
var getDeal = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((id) => {
	if (typeof id !== "string" || !UUID_RE.test(id)) fail("Некорректная сделка");
	return id;
}).handler(createSsrRpc("87cb89b952081dd8890bf80fc83f0c6f4b606459a63d45801e993a8cad3037ed"));
var getStaffDeal = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((input) => {
	const raw = typeof input === "number" ? input : typeof input === "string" ? Number(input.replace(/^#/, "")) : NaN;
	if (!Number.isInteger(raw) || raw < 1 || raw > 2e9) fail("Некорректный номер сделки");
	return raw;
}).handler(createSsrRpc("27ce83a3a55efad8781c21284926e7a95d438c45f156a8d37d59090fb1f548aa"));
var sendMessage = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!input || typeof input !== "object") fail("Пустое сообщение");
	const o = input;
	if (typeof o.dealId !== "string" || !UUID_RE.test(o.dealId)) fail("Некорректная сделка");
	const body = cleanText(typeof o.body === "string" ? o.body : "", 2e3);
	const withImages = o.withImages === true;
	if (!body && !withImages) fail("Напишите сообщение или приложите картинку");
	return {
		dealId: o.dealId,
		body,
		withImages
	};
}).handler(createSsrRpc("cd96842cb005bf8710540dfcd3084259dce0ac050c8f8d7b0eea2eb2832f1c08"));
var attachDealImage = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!input || typeof input !== "object") fail("Пустой файл");
	const o = input;
	if (typeof o.messageId !== "string" || !UUID_RE.test(o.messageId)) fail("Некорректное сообщение");
	if (typeof o.filename !== "string" || typeof o.b64 !== "string") fail("Файл не прочитан");
	const b64 = o.b64.replace(/^data:[^,]*,/, "").replace(/\s/g, "");
	if (b64.length > 46e5) fail("Картинка больше 3 МБ");
	return {
		messageId: o.messageId,
		filename: o.filename,
		b64
	};
}).handler(createSsrRpc("ae4a7787452aa76f6f34f4e86dc629c75cd69af46a20a646fc5015f987a24c32"));
var discardBlankMessage = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => {
	if (typeof id !== "string" || !UUID_RE.test(id)) fail("Некорректное сообщение");
	return id;
}).handler(createSsrRpc("34115d5b4238b5a456ffbcb3e51e43ee04f37d49cc802f48f554bb47fee4fb01"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => {
	if (typeof id !== "string" || !UUID_RE.test(id)) fail("Некорректная сделка");
	return id;
}).handler(createSsrRpc("e1712075d685bc0d0caed9dc60b5ed178cf3013175ed83a7c5c084f3a149173f"));
var setDealOpen = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!input || typeof input !== "object") fail("Пустой статус");
	const o = input;
	if (typeof o.id !== "string" || !UUID_RE.test(o.id)) fail("Некорректная сделка");
	if (typeof o.open !== "boolean") fail("Некорректный статус");
	return {
		id: o.id,
		open: o.open
	};
}).handler(createSsrRpc("77959c24fc8051718504adcd3826d9774ff142eaca43719bc37b3d6ad951bf31"));
var listNotifications = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("8eb96d9b05ba7785aee90e337b52ecdbe52aa9e51513b5c9f8a396fe6d97c587"));
var markNotificationsRead = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("b013d6dcf10d1862e53f81cbea06421661c4bda7df46d7fc3dbd182fe14c2dbf"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!input || typeof input !== "object") fail("Пустой комментарий");
	const o = input;
	const handle = cleanHandle(typeof o.handle === "string" ? o.handle : "");
	const body = cleanText(typeof o.body === "string" ? o.body : "", 500);
	if (!handle) fail("Некорректный профиль");
	if (body.length < 1) fail("Напишите комментарий");
	return {
		handle,
		body
	};
}).handler(createSsrRpc("3e2afcbefb863ae981b7b8b12c98a0b9edb94f93601231440dea35fbc4c1cf15"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => {
	if (typeof id !== "string" || !UUID_RE.test(id)) fail("Некорректный комментарий");
	return id;
}).handler(createSsrRpc("4a91b5260d0122f5f9c36e8f071316af619ca6fff4b83e0033a40d399e952549"));
var adminOverview = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("3df17bac92a5825de719790181e0bc3a35edeee951e478ebd74ad372243e0440"));
var adminModerate = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!input || typeof input !== "object") fail("Пустое действие");
	const o = input;
	if (o.action === "remove-listing" && typeof o.listingId === "string" && UUID_RE.test(o.listingId)) return {
		action: "remove-listing",
		listingId: o.listingId
	};
	if ((o.action === "dismiss-report" || o.action === "action-report") && typeof o.reportId === "string" && UUID_RE.test(o.reportId)) return {
		action: o.action,
		reportId: o.reportId
	};
	if (o.action === "ban" && typeof o.userId === "string" && typeof o.banned === "boolean") return {
		action: "ban",
		userId: o.userId,
		banned: o.banned
	};
	if (o.action === "set-role" && typeof o.userId === "string" && (o.role === "user" || o.role === "moderator" || o.role === "admin")) return {
		action: "set-role",
		userId: o.userId,
		role: o.role
	};
	if (o.action === "set-badges" && typeof o.userId === "string" && Array.isArray(o.badges)) {
		const badges = asBadges(o.badges);
		if (badges.length !== o.badges.length) fail("Неизвестный значок");
		return {
			action: "set-badges",
			userId: o.userId,
			badges
		};
	}
	if (o.action === "set-require-invite" && typeof o.enabled === "boolean") return {
		action: "set-require-invite",
		enabled: o.enabled
	};
	if (o.action === "create-invite") {
		const maxUses = Number(o.maxUses);
		const note = typeof o.note === "string" ? o.note.replace(/\s+/g, " ").trim().slice(0, 80) : "";
		if (!Number.isInteger(maxUses) || maxUses < 1 || maxUses > 100) fail("Число использований — от 1 до 100");
		return {
			action: "create-invite",
			maxUses,
			note
		};
	}
	if (o.action === "revoke-invite" && typeof o.inviteId === "string" && UUID_RE.test(o.inviteId)) return {
		action: "revoke-invite",
		inviteId: o.inviteId
	};
	if ((o.action === "grant-premium-month" || o.action === "grant-premium-forever" || o.action === "revoke-premium") && typeof o.userId === "string") return {
		action: o.action,
		userId: o.userId
	};
	fail("Некорректное действие");
}).handler(createSsrRpc("590fbe4f516b66724926c2bd8bfd9ac4efecf5a9d814134bd7063c7615b4a63e"));
var listRecommendations = createServerFn({ method: "GET" }).handler(createSsrRpc("6cb7d3aa24d56395e24def35b8f174a54e71185044b1ea2607d7ddf04554471c"));
var listMine = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("5dd13b4e213984ed0f4898b7f7680f2c3f922dc7abdad4bfd93a588d70ec5a4d"));
var setPinned = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!input || typeof input !== "object") fail("Пусто");
	const o = input;
	if (typeof o.id !== "string" || !UUID_RE.test(o.id)) fail("Некорректный лот");
	if (typeof o.pinned !== "boolean") fail("Некорректный флаг");
	return {
		id: o.id,
		pinned: o.pinned
	};
}).handler(createSsrRpc("c597ac2176cc3d723d4f53a6b6239749bdd0f9bc93a2f0309ad2c6c2c6678524"));
var boostListing = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!input || typeof input !== "object") fail("Пусто");
	const o = input;
	if (typeof o.id !== "string" || !UUID_RE.test(o.id)) fail("Некорректный лот");
	const hours = Number(o.hours);
	if (hours !== 24 && hours !== 48 && hours !== 72) fail("Буст на 24, 48 или 72 часа");
	return {
		id: o.id,
		hours
	};
}).handler(createSsrRpc("8f46f417c8f6cdcea2ab6703e3871ade5545f8422c6bbb4d50db915e07eb13d3"));
var setPostPinned = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!input || typeof input !== "object") fail("Пусто");
	const o = input;
	if (typeof o.id !== "string" || !UUID_RE.test(o.id)) fail("Некорректный пост");
	if (typeof o.pinned !== "boolean") fail("Некорректный флаг");
	return {
		id: o.id,
		pinned: o.pinned
	};
}).handler(createSsrRpc("6b4404dd658fbc8708505c0a1268984009a0d4ed71425839e6e2e9c80fad8e8d"));
var updateProfileLook = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!input || typeof input !== "object") fail("Пустая форма");
	const o = input;
	return {
		theme: asTheme(o.theme),
		accent: asAccent(o.accent),
		avatarFrame: asFrame(o.avatarFrame),
		bannerOverlay: asOverlay(o.bannerOverlay)
	};
}).handler(createSsrRpc("4562512718f4d7699d5f0c46e416b877854a34fa66e3b29768e23e4fcf2c4320"));
var toggleLike = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => {
	if (typeof id !== "string" || !UUID_RE.test(id)) fail("Некорректный лот");
	return id;
}).handler(createSsrRpc("4c6af4b2936811de664c2931b3bb241f81cc1f224eb6ee05e1ed6801d18916f0"));
var addListingComment = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!input || typeof input !== "object") fail("Пустой комментарий");
	const o = input;
	if (typeof o.listingId !== "string" || !UUID_RE.test(o.listingId)) fail("Некорректный лот");
	const body = cleanText(typeof o.body === "string" ? o.body : "", 500);
	if (body.length < 1) fail("Напишите комментарий");
	return {
		listingId: o.listingId,
		body
	};
}).handler(createSsrRpc("3308e17acbc6b0713724673e74efd1032146505a6063740ca44937803821778f"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => {
	if (typeof id !== "string" || !UUID_RE.test(id)) fail("Некорректный комментарий");
	return id;
}).handler(createSsrRpc("8ded6402d743f777c2ab9eedaa9149e43d922deef67b7cf26d186d278e2891e1"));
var uploadProfileImage = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!input || typeof input !== "object") fail("Пустой файл");
	const o = input;
	if (o.kind !== "avatar" && o.kind !== "banner" && o.kind !== "background") fail("Неизвестный кадр");
	if (typeof o.b64 !== "string") fail("Файл не прочитан");
	const b64 = o.b64.replace(/^data:[^,]*,/, "").replace(/\s/g, "");
	if (b64.length > 45e5) fail("Файл больше лимита");
	return {
		kind: o.kind,
		b64
	};
}).handler(createSsrRpc("ab22b38dd4d8fff1a30b516ea823a188db4c2fede36ac498cc9f2a81a6c59f4a"));
var clearProfileImage = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((kind) => {
	if (kind !== "avatar" && kind !== "banner" && kind !== "background") fail("Неизвестный кадр");
	return kind;
}).handler(createSsrRpc("d7cf33e6789853507fe940be3f51a5a8a5a18c2c5db9406381b881c1bf8f80fe"));
var listThreads = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("591dd9858617a99fe9f611ddc9c38eaa658b67cc5cfa71c0623e1a668e360a37"));
var openThread = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((handle) => {
	const h = typeof handle === "string" ? handle.trim().toLocaleLowerCase("ru") : "";
	if (!cleanHandle(h)) fail("Некорректный профиль");
	return h;
}).handler(createSsrRpc("b024eac2a894659f9a6b8f4a406e3147dd451fd2b5432a5e14e8f663a17cb684"));
var getThread = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((id) => {
	if (typeof id !== "string" || !UUID_RE.test(id)) fail("Некорректный чат");
	return id;
}).handler(createSsrRpc("a5da4b4a3da29f12d91f8564681332daa72ad187fd2571b6b0ca344e19c68df0"));
var sendDirect = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!input || typeof input !== "object") fail("Пустое сообщение");
	const o = input;
	let threadId = "";
	if (typeof o.threadId === "string" && UUID_RE.test(o.threadId)) threadId = o.threadId;
	const handle = typeof o.handle === "string" ? o.handle.trim().toLocaleLowerCase("ru") : "";
	if (!threadId && !cleanHandle(handle)) fail("Некорректный чат");
	const body = cleanText(typeof o.body === "string" ? o.body : "", 2e3);
	if (body.length < 1) fail("Напишите сообщение");
	return {
		threadId,
		handle,
		body
	};
}).handler(createSsrRpc("426f068d01555795b1f86860bffec2cc4a8b6fbd0dea3d7e8d197009c66269d1"));
var listProfileLots = createServerFn({ method: "GET" }).validator((input) => {
	if (!input || typeof input !== "object") fail("Некорректный профиль");
	const o = input;
	const handle = typeof o.handle === "string" ? o.handle.trim().toLocaleLowerCase("ru") : "";
	if (!cleanHandle(handle)) fail("Некорректный профиль");
	const page = Number(o.page);
	return {
		handle,
		page: Number.isInteger(page) && page > 0 && page < 500 ? page : 1
	};
}).handler(createSsrRpc("270a646a5dd83412b41f31f883c2f1f9977fbac0db89271ef607d2aceae1c21c"));
var toggleFollow = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((handle) => {
	const h = typeof handle === "string" ? handle.trim().toLocaleLowerCase("ru") : "";
	if (!cleanHandle(h)) fail("Некорректный профиль");
	return h;
}).handler(createSsrRpc("f6249829c2837088c12cac9afe04cb44db75ff6d9771578630f9570918c49aa5"));
var listFeed = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("3fd27d26e3402c983d4311224be24e457b6e5223ee479a5fe3e674328f659153"));
var createPost = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!input || typeof input !== "object") fail("Пустой пост");
	const o = input;
	const body = cleanText(typeof o.body === "string" ? o.body : "", 2e3);
	if (body.length < 1) fail("Напишите текст поста");
	const images = Array.isArray(o.images) ? o.images.filter((item) => typeof item === "string") : [];
	if (images.length > 4) fail("Не больше 4 картинок");
	return {
		body,
		images: images.map((item) => item.replace(/^data:[^,]*,/, "").replace(/\s/g, ""))
	};
}).handler(createSsrRpc("ffa2d319f3c13a95f53bba28f7a7ebe3a3e0efaf004c8ce6ad2c0d3c682efccc"));
var addPostComment = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!input || typeof input !== "object") fail("Пустой комментарий");
	const o = input;
	if (typeof o.postId !== "string" || !UUID_RE.test(o.postId)) fail("Некорректный пост");
	const parentId = typeof o.parentId === "string" && UUID_RE.test(o.parentId) ? o.parentId : null;
	const body = cleanText(typeof o.body === "string" ? o.body : "", 500);
	if (body.length < 1) fail("Напишите комментарий");
	return {
		postId: o.postId,
		parentId,
		body
	};
}).handler(createSsrRpc("ee2e17eade8b79b4ee4dbe698e23b87e0140ce3bf769738a8c2a828882978ad8"));
var deletePost = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => {
	if (typeof id !== "string" || !UUID_RE.test(id)) fail("Некорректный пост");
	return id;
}).handler(createSsrRpc("6af6153d067a6c0ee42f549cddc029e42e4b6fa9cb7768e0007fafe692c21363"));
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-FBojnzgg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_react_dom = /* @__PURE__ */ __toESM(require_react_dom());
function asBody(buf) {
	const out = new Uint8Array(buf.byteLength);
	out.set(buf);
	return out;
}
function bodyBuffer(bytes) {
	const copy = new Uint8Array(bytes.byteLength);
	copy.set(bytes);
	return copy.buffer;
}
/** Whole body in one response. No image library, no stream. */
function imageResponse(bytes, mime, cacheSeconds) {
	const body = bodyBuffer(bytes);
	return new Response(body, {
		status: 200,
		headers: {
			"content-type": mime,
			"content-length": String(body.byteLength),
			"x-content-type-options": "nosniff",
			"content-disposition": "inline",
			"cache-control": cacheSeconds > 0 ? `public, max-age=${cacheSeconds}` : "private, no-store"
		}
	});
}
var FALLBACK_MESSAGE = "Что-то сломалось. Обновите страницу.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 bg-paper px-6 text-center text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
				className: "size-10",
				strokeWidth: 1.5,
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl",
				children: "Сбой"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-muted",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
/**
* Current user + loading state. Same behavior in live preview and when deployed:
*   - Auth enabled -> the real signed-in user; `user` is `null` while
*                            the session resolves (`isPending: true`) and when
*                            signed out (`isPending: false`). Session comes from
*                            Better Auth `useSession()` → `/api/auth/get-session`
*                            (cookie when deployed; bearer in live preview).
*   - Auth disabled (`VITE_AUTH_ENABLED=false`) -> `DEV_USER`, never pending.
*
* Protect a route by waiting out `isPending` before acting on `user` —
* redirecting on `user: null` alone bounces signed-in visitors to sign-in on
* every hard reload:
*
*   import { RedirectToSignIn } from "@/lib/auth/gates";
*   const { user, isPending } = useCurrentUserState();
*   if (isPending) return null;              // still resolving — don't redirect yet
*   if (!user) return <RedirectToSignIn />;  // definitely signed out
*
* `authEnabled` is a module-level constant fixed at load, so the guarded hook
* call keeps a stable hook order across every render of a given component.
*/
function useCurrentUserState() {
	return useSessionUserState();
}
function useSessionUserState() {
	const { data, isPending } = authClient.useSession();
	const id = data?.user.id;
	const displayName = data?.user.name ?? null;
	const primaryEmail = data?.user.email ?? null;
	const profileImageUrl = data?.user.image ?? null;
	const user = (0, import_react.useMemo)(() => id ? {
		id,
		displayName,
		primaryEmail,
		profileImageUrl,
		isDevFallback: false
	} : null, [
		id,
		displayName,
		primaryEmail,
		profileImageUrl
	]);
	return (0, import_react.useMemo)(() => ({
		user,
		isPending
	}), [user, isPending]);
}
var THEME_KEY = "adoptai-theme";
var themeBoot = `(function(){try{if(localStorage.getItem("${THEME_KEY}")==="light")document.documentElement.classList.add("light")}catch(e){}})();`;
function emit() {
	window.dispatchEvent(new Event("adoptai-theme"));
}
function siteThemeSnapshot() {
	return document.documentElement.classList.contains("light") ? "light" : "dark";
}
function subscribeSiteTheme(onChange) {
	window.addEventListener("adoptai-theme", onChange);
	window.addEventListener("storage", onChange);
	return () => {
		window.removeEventListener("adoptai-theme", onChange);
		window.removeEventListener("storage", onChange);
	};
}
function toggleSiteTheme() {
	const next = !document.documentElement.classList.contains("light");
	document.documentElement.classList.toggle("light", next);
	try {
		localStorage.setItem(THEME_KEY, next ? "light" : "dark");
	} catch {}
	document.querySelector("meta[name=\"theme-color\"]")?.setAttribute("content", next ? "#eceae6" : "#131211");
	emit();
}
var subscribeToNothing = () => () => {};
var noGateSessionOnServer = () => false;
function SearchForm({ className }) {
	const navigate = useNavigate();
	const [q, setQ] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
		className,
		role: "search",
		onSubmit: (e) => {
			e.preventDefault();
			navigate({
				to: "/",
				search: {
					q: q.trim(),
					tag: "",
					kind: "all",
					sort: "new",
					page: 1
				}
			});
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "flex min-h-11 items-center gap-2 border border-ink/25 bg-card px-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
				className: "size-4 shrink-0 text-muted",
				"aria-hidden": "true"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: q,
				onChange: (e) => setQ(e.target.value),
				placeholder: "Название или @ник",
				className: "w-full bg-transparent text-sm outline-none placeholder:text-muted",
				suppressHydrationWarning: true
			})]
		})
	});
}
function Mark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "relative grid size-10 place-items-center border border-wine/80",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pointer-events-none absolute -top-px -left-px h-2 w-2 border-t border-l border-wine" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pointer-events-none absolute -top-px -right-px h-2 w-2 border-t border-r border-wine" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pointer-events-none absolute -bottom-px -left-px h-2 w-2 border-b border-l border-wine" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pointer-events-none absolute -right-px -bottom-px h-2 w-2 border-r border-b border-wine" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-display text-lg leading-none text-ink",
				children: "A"
			})
		]
	});
}
function AccountMenu({ me }) {
	const { user } = useCurrentUserState();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	const root = (0, import_react.useRef)(null);
	const pathname = useRouterState({ select: (s) => s.location.href });
	const gateSession = (0, import_react.useSyncExternalStore)(subscribeToNothing, hasGateSessionMarker, noGateSessionOnServer);
	(0, import_react.useEffect)(() => {
		setOpen(false);
	}, [pathname]);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onPointer = (event) => {
			if (!root.current?.contains(event.target)) setOpen(false);
		};
		const onKey = (event) => {
			if (event.key === "Escape") setOpen(false);
		};
		document.addEventListener("mousedown", onPointer);
		document.addEventListener("keydown", onKey);
		return () => {
			document.removeEventListener("mousedown", onPointer);
			document.removeEventListener("keydown", onKey);
		};
	}, [open]);
	if (!user) return null;
	const label = user.displayName ?? user.primaryEmail ?? "Профиль";
	const initial = label.charAt(0).toLocaleUpperCase("ru");
	const itemClass = "flex min-h-11 items-center px-3 font-mono text-xs tracking-wide uppercase hover:bg-wine/25";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative",
		ref: root,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-haspopup": "menu",
			"aria-expanded": open,
			"aria-label": "Меню профиля",
			onClick: () => setOpen((value) => !value),
			className: "grid size-11 place-items-center border border-ink/25",
			children: user.profileImageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: user.profileImageUrl,
				alt: "",
				className: "size-7 object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid size-7 place-items-center border border-wine/70 bg-wine-deep text-sm text-foam",
				children: initial
			})
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "menu",
			className: "absolute top-full right-0 z-50 mt-2 w-52 border border-ink/30 bg-paper shadow-lg",
			children: [
				me?.handle ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/u/$handle",
					params: { handle: me.handle },
					role: "menuitem",
					className: itemClass,
					children: [
						me.premium ? "★ " : "",
						"@",
						me.handle
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate border-b border-ink/15 px-3 py-2 font-mono text-[10px] tracking-widest text-muted uppercase",
					children: label
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/studio",
					role: "menuitem",
					className: itemClass,
					children: "Мои лоты"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/deals",
					role: "menuitem",
					className: itemClass,
					children: "Сделки"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/chats",
					search: { with: "" },
					role: "menuitem",
					className: itemClass,
					children: "Чаты"
				}),
				me && isStaff(me.role) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/admin",
					role: "menuitem",
					className: itemClass,
					children: "Модерация"
				}) : null,
				!gateSession ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					role: "menuitem",
					disabled: signingOut,
					onClick: () => {
						setSigningOut(true);
						signOut().catch(() => setSigningOut(false));
					},
					className: `${itemClass} w-full border-t border-ink/15 text-left disabled:cursor-wait`,
					children: signingOut ? "Выход…" : "Выйти"
				}) : null
			]
		}) : null]
	});
}
function SignalsButton({ unread, onRead }) {
	const { user } = useCurrentUserState();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [items, setItems] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		if (user) listNotifications().then(setItems).catch((err) => toast.error(errText(err)));
		const onKey = (event) => {
			if (event.key === "Escape") setOpen(false);
		};
		document.addEventListener("keydown", onKey);
		return () => document.removeEventListener("keydown", onKey);
	}, [open, user]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		"aria-label": unread > 0 ? `Сигналы, ${unread}` : "Сигналы",
		"aria-expanded": open,
		onClick: () => setOpen(true),
		className: "relative grid size-11 place-items-center border border-ink/25",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-4" }), unread > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "absolute -top-1 -right-1 grid min-w-5 place-items-center bg-wine px-1 font-mono text-xs text-foam",
			children: unread > 9 ? "9+" : unread
		}) : null]
	}), open && typeof document !== "undefined" ? (0, import_react_dom.createPortal)(/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0",
		style: { zIndex: 400 },
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": "Закрыть сигналы",
			className: "absolute inset-0 bg-paper/70",
			onClick: () => setOpen(false)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "drawer-in absolute inset-y-0 right-0 z-10 flex w-full max-w-md flex-col border-l border-ink/30 bg-paper shadow-2xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3 border-b border-ink/20 px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl leading-none",
					children: "Сигналы"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Закрыть",
					onClick: () => setOpen(false),
					className: "relative z-10 grid size-11 place-items-center border border-ink/25",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
				})]
			}), !user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "p-4 text-sm text-muted",
				children: [
					"Войдите, чтобы видеть сигналы.",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/login",
						className: "text-ink underline",
						onClick: () => setOpen(false),
						children: "Войти"
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-end px-4 py-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "min-h-9 border border-ink/25 px-3 font-mono text-xs",
					onClick: () => {
						markNotificationsRead().then(() => {
							onRead();
							return listNotifications();
						}).then(setItems).catch((err) => toast.error(errText(err)));
					},
					children: "Прочитать все"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-0 flex-1 overflow-y-auto",
				children: items == null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "m-4 h-24 animate-pulse bg-soft" }) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-4 text-sm text-muted",
					children: "Тихо. Ставки, конец аукциона, сообщения и комментарии появятся здесь."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y divide-ink/10",
					children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: item.read ? "" : "border-l-2 border-l-wine bg-wine/15",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: item.href,
							className: "block px-4 py-3",
							onClick: () => setOpen(false),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: item.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: item.body
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 font-mono text-xs text-muted",
									suppressHydrationWarning: true,
									children: formatWhen(item.createdAt)
								})
							]
						})
					}, item.id))
				})
			})] })]
		})]
	}), document.body) : null] });
}
function PixelHearts() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex items-center justify-center gap-2.5 border-b border-ink/10 py-3",
		"aria-hidden": "true",
		children: [
			1,
			1,
			1,
			0,
			1,
			1,
			0,
			1,
			0,
			1,
			1,
			1
		].map((on, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
			width: "13",
			height: "11",
			viewBox: "0 0 7 6",
			shapeRendering: "crispEdges",
			className: on ? "text-ink" : "text-ink/30",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "currentColor",
				d: "M1 0h2v1H1zm3 0h2v1H4zM0 1h7v2H0zM1 3h5v1H1zM2 4h3v1H2zM3 5h1v1H3z"
			})
		}, index))
	});
}
function AppShell({ children }) {
	const { user, isPending } = useCurrentUserState();
	const [me, setMe] = (0, import_react.useState)(null);
	const userId = user?.id;
	(0, import_react.useLayoutEffect)(() => {
		try {
			document.documentElement.classList.toggle("light", localStorage.getItem(THEME_KEY) === "light");
		} catch {}
	}, []);
	(0, import_react.useEffect)(() => {
		if (!userId) {
			setMe(null);
			return;
		}
		let stop = false;
		const load = () => {
			getMe().then((next) => {
				if (!stop) setMe(next);
			}).catch(() => void 0);
		};
		load();
		const timer = window.setInterval(load, 2e4);
		return () => {
			stop = true;
			window.clearInterval(timer);
		};
	}, [userId]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-screen flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#content",
				className: "sr-only focus:not-sr-only focus:absolute focus:z-50 focus:bg-wine focus:px-3 focus:py-2 focus:text-foam",
				children: "К содержанию"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "relative z-50 border-b border-ink/20 bg-paper/95 backdrop-blur-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex w-full max-w-[100rem] items-center justify-between px-4 pt-2 font-mono text-[10px] tracking-[0.2em] text-muted uppercase",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "SYS // 01" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden sm:inline",
							children: "+ live booth"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "pay off-site" })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex w-full max-w-[100rem] flex-wrap items-center gap-3 px-4 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/",
							search: {
								q: "",
								tag: "",
								kind: "all",
								sort: "new",
								page: 1
							},
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "leading-none",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-display text-xl tracking-tight",
									children: "AdoptAI"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-[10px] tracking-widest text-muted",
									children: "ADOPT BOOTH"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchForm, { className: "hidden min-w-0 flex-1 md:block" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
							className: "ml-auto flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignalsButton, {
									unread: me?.unread ?? 0,
									onRead: () => setMe((current) => current ? {
										...current,
										unread: 0
									} : current)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									"aria-label": "Переключить тему",
									onClick: toggleSiteTheme,
									className: "grid size-11 place-items-center border border-ink/25",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "theme-sun size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "theme-moon size-4" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/feed",
									className: "inline-flex min-h-11 items-center border border-ink/25 px-3 font-medium",
									children: "Лента"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/sell",
									className: "inline-flex min-h-11 items-center gap-1 border border-wine bg-wine px-4 font-medium text-foam",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Лот"]
								}),
								isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-11 animate-pulse bg-soft" }) : user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountMenu, { me }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/login",
									className: "inline-flex min-h-11 items-center border border-ink/25 px-3 font-medium",
									children: "Войти"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchForm, { className: "w-full md:hidden" })
					]
				})]
			}),
			me?.banned ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "border-b border-wine bg-wine-deep px-4 py-2 text-center text-sm text-foam",
				children: "Аккаунт ограничен модерацией. Новые лоты и ставки недоступны."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				id: "content",
				className: "mx-auto flex w-full max-w-[100rem] min-h-0 flex-1 flex-col px-4 py-4 sm:py-6",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "border-t border-ink/20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PixelHearts, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex w-full max-w-[100rem] flex-wrap items-center gap-x-4 gap-y-2 px-4 py-4 font-mono text-xs text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "ADOPTAI // OFF-SITE PAY" }),
						me && isStaff(me.role) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/admin",
							className: "hover:text-ink",
							children: "Модерация"
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/rules",
							className: "hover:text-ink",
							children: "Правила"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/terms",
							className: "hover:text-ink",
							children: "Условия"
						})
					]
				})]
			})
		]
	});
}
var styles_default = "/assets/styles-CtpQ4SV1.css";
var Route$22 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "AdoptAI — маркетплейс адоптов" },
			{
				name: "description",
				content: "Аукционы и фиксированная цена на персонажей. Оплата вне площадки, переписка в сделке."
			},
			{
				name: "theme-color",
				content: "#131211"
			}
		],
		links: [{
			rel: "icon",
			type: "image/svg+xml",
			href: "/favicon.svg"
		}, {
			rel: "stylesheet",
			href: styles_default
		}]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "ru",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("head", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", { dangerouslySetInnerHTML: { __html: themeBoot } }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
			position: "top-center",
			toastOptions: { style: {
				background: "var(--color-card)",
				color: "var(--color-ink)",
				border: "1px solid var(--color-ink)",
				borderRadius: "2px"
			} }
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	})
});
function isHome(search) {
	return !search.q && !search.tag && search.kind === "all";
}
var $$splitComponentImporter$16 = () => import("./routes-CPaj1NSq.mjs");
var emptyFeed = {
	items: [],
	total: 0,
	hasMore: false
};
var Route$21 = createFileRoute("/")({
	validateSearch: (search) => parseFeedQuery(search),
	loaderDeps: ({ search }) => search,
	loader: async ({ deps }) => {
		const home = isHome(deps);
		const peopleQuery = deps.q.startsWith("@") ? deps.q : "";
		const listingQuery = peopleQuery ? {
			...deps,
			q: peopleQuery.replace(/^@+/, "")
		} : deps;
		const [feed, tags, recommended, people] = await Promise.all([
			home ? Promise.resolve(emptyFeed) : listListings({ data: listingQuery }),
			listPopularTags().catch(() => []),
			home ? listRecommendations().catch(() => []) : Promise.resolve([]),
			peopleQuery ? searchPeople({ data: peopleQuery }).catch(() => []) : Promise.resolve([])
		]);
		return [
			feed,
			tags,
			recommended,
			people
		];
	},
	head: () => ({ meta: [{ title: "AdoptAI — открытые лоты" }] }),
	component: lazyRouteComponent($$splitComponentImporter$16, "component")
});
var $$splitComponentImporter$15 = () => import("./admin-CMZ7tX3h.mjs");
var Route$20 = createFileRoute("/admin")({
	head: () => ({ meta: [{ title: "Модерация — AdoptAI" }] }),
	component: lazyRouteComponent($$splitComponentImporter$15, "component")
});
var $$splitComponentImporter$14 = () => import("./chats-DbHCGU63.mjs");
var Route$19 = createFileRoute("/chats")({
	validateSearch: (search) => ({ with: typeof search.with === "string" ? search.with.trim().slice(0, 24) : "" }),
	head: () => ({ meta: [{ title: "Чаты — AdoptAI" }] }),
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var $$splitComponentImporter$13 = () => import("./feed-B52rqZwa.mjs");
var Route$18 = createFileRoute("/feed")({
	loader: () => listFeed().catch(() => []),
	head: () => ({ meta: [{ title: "Лента — AdoptAI" }] }),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("./forgot-CIIzYA6d.mjs");
var Route$17 = createFileRoute("/forgot")({
	head: () => ({ meta: [{ title: "Сброс пароля — AdoptAI" }] }),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var $$splitComponentImporter$11 = () => import("./login-BsLRxi3d.mjs");
var Route$16 = createFileRoute("/login")({
	head: () => ({ meta: [{ title: "Вход — AdoptAI" }] }),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./me-DykHdgqS.mjs");
var Route$15 = createFileRoute("/me")({
	head: () => ({ meta: [{ title: "Профиль — AdoptAI" }] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var Route$14 = createFileRoute("/notifications")({ beforeLoad: () => {
	throw redirect({
		to: "/",
		search: {
			q: "",
			tag: "",
			kind: "all",
			sort: "new",
			page: 1
		}
	});
} });
var $$splitComponentImporter$9 = () => import("./reset-password-Blh2AkEd.mjs");
var Route$13 = createFileRoute("/reset-password")({
	validateSearch: (search) => ({ token: typeof search.token === "string" ? search.token : "" }),
	head: () => ({ meta: [{ title: "Новый пароль — AdoptAI" }] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./rules-BjmX0cPo.mjs");
var Route$12 = createFileRoute("/rules")({
	head: () => ({ meta: [{ title: "Правила — AdoptAI" }] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./sell-CIKuUIJZ.mjs");
var Route$11 = createFileRoute("/sell")({
	head: () => ({ meta: [{ title: "Новый лот — AdoptAI" }] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./studio-BuD1-m4N.mjs");
var Route$10 = createFileRoute("/studio")({
	head: () => ({ meta: [{ title: "Мои лоты — AdoptAI" }] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./terms-DIMhxX05.mjs");
var Route$9 = createFileRoute("/terms")({
	head: () => ({ meta: [{ title: "Условия — AdoptAI" }] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./deals.index-_QCTbvA5.mjs");
var Route$8 = createFileRoute("/deals/")({
	head: () => ({ meta: [{ title: "Сделки — AdoptAI" }] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./deals._id-D0ErTCpP.mjs");
var Route$7 = createFileRoute("/deals/$id")({
	head: () => ({ meta: [{ title: "Сделка — AdoptAI" }] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./lot._id-Ccy74h8v.mjs");
var Route$6 = createFileRoute("/lot/$id")({
	loader: ({ params }) => getListing({ data: params.id }),
	head: ({ loaderData }) => ({ meta: [{ title: loaderData ? `${loaderData.title} — AdoptAI` : "Лот — AdoptAI" }] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./u._handle-D4JWuNw-.mjs");
var Route$5 = createFileRoute("/u/$handle")({
	loader: ({ params }) => getPublicProfile({ data: {
		handle: params.handle,
		page: 1
	} }),
	head: ({ loaderData }) => ({ meta: [{ title: loaderData ? `@${loaderData.handle} — AdoptAI` : "Профиль — AdoptAI" }] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./admin.deal._no-BuevSQgQ.mjs");
var Route$4 = createFileRoute("/admin/deal/$no")({
	head: () => ({ meta: [{ title: "Переписка — AdoptAI" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
/**
* Direct Google sign-in for neurohh.ru.
*
* Uses GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET on this app. The redirect URI
* Google must allow is exactly:
* https://neurohh.ru/api/auth/callback/google
* After success Better Auth sends the browser to https://neurohh.ru/.
*/
var GOOGLE_REDIRECT = `${SITE_ORIGIN}/api/auth/callback/google`;
function requestOrigin(request) {
	const url = new URL(request.url);
	const host = (request.headers.get("x-forwarded-host")?.split(",")[0]?.trim() || request.headers.get("host") || url.host).toLowerCase();
	const proto = request.headers.get("x-forwarded-proto")?.split(",")[0]?.trim() || (host.endsWith(".grok-sandbox.com") || host === "localhost" || host.startsWith("127.") ? "http" : "https");
	const hostname = host.split(":")[0] ?? host;
	return `${hostname === "localhost" || hostname === "127.0.0.1" || hostname === "[::1]" ? "http" : proto}://${host}`;
}
function hostOf(origin) {
	try {
		return new URL(origin).hostname.toLowerCase();
	} catch {
		return "";
	}
}
function html(message) {
	const body = `<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Google</title><body style="margin:0;min-height:100vh;display:grid;place-items:center;background:#131211;color:#f4efe8;font:16px/1.5 Georgia,serif"><main style="max-width:28rem;padding:1.5rem"><h1 style="font-weight:500;font-size:1.6rem">Google не пустил обратно</h1><p>${message}</p><p>Нужный redirect URI: ${GOOGLE_REDIRECT}</p><p><a style="color:#f4efe8" href="${SITE_ORIGIN}/login">Вернуться ко входу</a></p></main>`;
	return new Response(body, {
		status: 400,
		headers: {
			"content-type": "text/html; charset=utf-8",
			"cache-control": "no-store"
		}
	});
}
async function startPublicGoogle(request) {
	const id = process.env.GOOGLE_CLIENT_ID?.trim();
	const secret = process.env.GOOGLE_CLIENT_SECRET?.trim();
	if (!id || !secret) return html("На сервере нет GOOGLE_CLIENT_ID и GOOGLE_CLIENT_SECRET.");
	const host = hostOf(requestOrigin(request));
	if (host !== "neurohh.ru" && host !== "localhost" && host !== "127.0.0.1") return Response.redirect(`${SITE_ORIGIN}/api/auth/google`, 302);
	const origin = host === "neurohh.ru" ? SITE_ORIGIN : requestOrigin(request);
	const start = new Request(`${origin}/api/auth/sign-in/social`, {
		method: "POST",
		headers: {
			"content-type": "application/json",
			origin,
			cookie: request.headers.get("cookie") ?? "",
			"x-forwarded-host": host,
			"x-forwarded-proto": origin.startsWith("http://") ? "http" : "https"
		},
		body: JSON.stringify({
			provider: "google",
			callbackURL: host === "neurohh.ru" ? `${SITE_ORIGIN}/` : "/",
			errorCallbackURL: host === "neurohh.ru" ? `${SITE_ORIGIN}/login` : "/login"
		})
	});
	const res = await auth.handler(start);
	if (res.status >= 300 && res.status < 400) return res;
	const data = await res.json().catch(() => null);
	const url = typeof data?.url === "string" ? data.url : "";
	if (!url.startsWith("https://accounts.google.com/")) return html("Не удалось начать вход через Google.");
	const headers = new Headers({
		location: url,
		"cache-control": "no-store"
	});
	for (const cookie of res.headers.getSetCookie()) headers.append("set-cookie", cookie);
	return new Response(null, {
		status: 302,
		headers
	});
}
function socialDisabled() {
	return new Response("Вход через соцсети отключён. Используйте email и пароль на сайте.", {
		status: 410,
		headers: { "content-type": "text/plain; charset=utf-8" }
	});
}
async function handle(request) {
	const path = new URL(request.url).pathname;
	if (path === "/api/auth/google") return startPublicGoogle(request);
	if (path === "/api/auth/callback/google") return auth.handler(request);
	if (path === "/api/auth/sign-in/social") {
		let provider = "";
		try {
			const body = await request.clone().json();
			provider = typeof body.provider === "string" ? body.provider : "";
		} catch {
			provider = "";
		}
		if (provider !== "google") return socialDisabled();
		return auth.handler(request);
	}
	if (path === "/api/auth/handoff" || path.includes("/oauth2/") || path.includes("/sign-in/telegram") || path.includes("/callback/vk") || path.includes("/sign-in/social") || path.includes("/callback/")) return socialDisabled();
	return auth.handler(request);
}
var Route$3 = createFileRoute("/api/auth/$")({ server: { handlers: {
	GET: ({ request }) => handle(request),
	POST: ({ request }) => handle(request)
} } });
/** Original chat picture. Participants and staff only. No recompression. */
var Route$2 = createFileRoute("/api/chat-image/$id")({ server: { handlers: { GET: async ({ params, request }) => {
	if (!UUID_RE.test(params.id)) return new Response("bad", { status: 400 });
	try {
		const { auth } = await import("./server-D0fyK5tr.mjs").then((n) => n.r);
		const userId = (await auth.api.getSession({ headers: request.headers }))?.user?.id;
		if (!userId) return new Response("unauthorized", {
			status: 401,
			headers: { "cache-control": "no-store" }
		});
		const { getSql } = await import("./db-B6SjOW4g.mjs").then((n) => n.t).then((n) => n.t);
		const sql = await getSql();
		const row = (await sql`
            select i.filename, i.mime, i.data_b64, d.seller_id, d.buyer_id
            from message_images i
            join messages m on m.id = i.message_id
            join deals d on d.id = m.deal_id
            where i.id = ${params.id}
          `)[0];
		if (!row?.data_b64) return new Response("not found", {
			status: 404,
			headers: { "cache-control": "no-store" }
		});
		let allowed = row.seller_id === userId || row.buyer_id === userId;
		if (!allowed) {
			const role = await sql`select role from profiles where user_id = ${userId}`;
			allowed = isStaff(asRole(role[0]?.role));
		}
		if (!allowed) return new Response("not found", {
			status: 404,
			headers: { "cache-control": "no-store" }
		});
		if (row.data_b64.length > 6e6) return new Response("too large", {
			status: 413,
			headers: { "cache-control": "no-store" }
		});
		const bytes = Buffer.from(row.data_b64, "base64");
		const body = new Uint8Array(bytes.byteLength);
		body.set(bytes);
		const download = new URL(request.url).searchParams.get("download") === "1";
		const ascii = row.filename.replace(/[^\w.\-]+/g, "_").slice(0, 80) || "image";
		const disposition = download ? `attachment; filename="${ascii}"; filename*=UTF-8''${encodeURIComponent(row.filename)}` : "inline";
		return new Response(body.buffer, {
			status: 200,
			headers: {
				"content-type": row.mime.startsWith("image/") ? row.mime : "application/octet-stream",
				"content-length": String(body.byteLength),
				"content-disposition": disposition,
				"x-content-type-options": "nosniff",
				"cache-control": "private, max-age=3600"
			}
		});
	} catch (err) {
		console.error("[chat-image]", err instanceof Error ? err.message : err);
		return new Response("unavailable", {
			status: 503,
			headers: {
				"cache-control": "no-store",
				"content-type": "text/plain; charset=utf-8"
			}
		});
	}
} } } });
/** Only a stored thumbnail. Never the original file — that response was closing the connection. */
var Route$1 = createFileRoute("/api/media/$id")({ server: { handlers: { GET: async ({ params, request }) => {
	if (!UUID_RE.test(params.id)) return new Response("bad", { status: 400 });
	const variant = new URL(request.url).searchParams.get("s") === "view" ? "view" : "card";
	try {
		const { getSql } = await import("./db-B6SjOW4g.mjs").then((n) => n.t).then((n) => n.t);
		const row = (await (await getSql())`
            select m.card_b64, m.view_b64, l.status
            from media m
            join listings l on l.id = m.listing_id
            where m.id = ${params.id} and m.kind = 'preview'
          `)[0];
		if (!row || row.status === "removed") return new Response("not found", {
			status: 404,
			headers: { "cache-control": "no-store" }
		});
		const b64 = variant === "view" ? row.view_b64 || row.card_b64 : row.card_b64 || row.view_b64;
		if (!b64 || b64.length < 32 || b64.length > 4e5) return new Response("not found", {
			status: 404,
			headers: { "cache-control": "no-store" }
		});
		return imageResponse(asBody(Buffer.from(b64, "base64")), "image/jpeg", 86400);
	} catch (err) {
		console.error("[media] read failed:", err instanceof Error ? err.message : err);
		return new Response("unavailable", {
			status: 503,
			headers: {
				"cache-control": "no-store",
				"content-type": "text/plain; charset=utf-8"
			}
		});
	}
} } } });
var KINDS = /* @__PURE__ */ new Set([
	"avatar",
	"banner",
	"background"
]);
var Route = createFileRoute("/api/profile-image/$handle")({ server: { handlers: { GET: async ({ params, request }) => {
	const kind = new URL(request.url).searchParams.get("kind") ?? "";
	if (!KINDS.has(kind)) return new Response("bad", { status: 400 });
	const handle = params.handle.trim().toLocaleLowerCase("ru");
	try {
		const { getSql } = await import("./db-B6SjOW4g.mjs").then((n) => n.t).then((n) => n.t);
		const { asBody, imageResponse } = await import("./image-response-Dy46Zfys.mjs");
		const row = (await (await getSql())`
            select i.mime, i.data_b64
            from profile_images i
            join profiles p on p.user_id = i.user_id
            where p.handle = ${handle} and i.kind = ${kind}
          `)[0];
		if (!row?.data_b64) return new Response("not found", {
			status: 404,
			headers: { "cache-control": "no-store" }
		});
		const mime = row.mime.startsWith("image/") ? row.mime : "image/jpeg";
		return imageResponse(asBody(Buffer.from(row.data_b64, "base64")), mime, 600);
	} catch (err) {
		console.error("[profile-image] read failed:", err instanceof Error ? err.message : err);
		return new Response("unavailable", {
			status: 503,
			headers: {
				"cache-control": "no-store",
				"content-type": "text/plain; charset=utf-8"
			}
		});
	}
} } } });
var IndexRoute = Route$21.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$22
});
var AdminRoute = Route$20.update({
	id: "/admin",
	path: "/admin",
	getParentRoute: () => Route$22
});
var ChatsRoute = Route$19.update({
	id: "/chats",
	path: "/chats",
	getParentRoute: () => Route$22
});
var FeedRoute = Route$18.update({
	id: "/feed",
	path: "/feed",
	getParentRoute: () => Route$22
});
var ForgotRoute = Route$17.update({
	id: "/forgot",
	path: "/forgot",
	getParentRoute: () => Route$22
});
var LoginRoute = Route$16.update({
	id: "/login",
	path: "/login",
	getParentRoute: () => Route$22
});
var MeRoute = Route$15.update({
	id: "/me",
	path: "/me",
	getParentRoute: () => Route$22
});
var NotificationsRoute = Route$14.update({
	id: "/notifications",
	path: "/notifications",
	getParentRoute: () => Route$22
});
var ResetPasswordRoute = Route$13.update({
	id: "/reset-password",
	path: "/reset-password",
	getParentRoute: () => Route$22
});
var RulesRoute = Route$12.update({
	id: "/rules",
	path: "/rules",
	getParentRoute: () => Route$22
});
var SellRoute = Route$11.update({
	id: "/sell",
	path: "/sell",
	getParentRoute: () => Route$22
});
var StudioRoute = Route$10.update({
	id: "/studio",
	path: "/studio",
	getParentRoute: () => Route$22
});
var TermsRoute = Route$9.update({
	id: "/terms",
	path: "/terms",
	getParentRoute: () => Route$22
});
var DealsIndexRoute = Route$8.update({
	id: "/deals/",
	path: "/deals/",
	getParentRoute: () => Route$22
});
var DealsIdRoute = Route$7.update({
	id: "/deals/$id",
	path: "/deals/$id",
	getParentRoute: () => Route$22
});
var LotIdRoute = Route$6.update({
	id: "/lot/$id",
	path: "/lot/$id",
	getParentRoute: () => Route$22
});
var UHandleRoute = Route$5.update({
	id: "/u/$handle",
	path: "/u/$handle",
	getParentRoute: () => Route$22
});
var AdminDealNoRoute = Route$4.update({
	id: "/deal/$no",
	path: "/deal/$no",
	getParentRoute: () => AdminRoute
});
var ApiAuthSplatRoute = Route$3.update({
	id: "/api/auth/$",
	path: "/api/auth/$",
	getParentRoute: () => Route$22
});
var ApiChatImageIdRoute = Route$2.update({
	id: "/api/chat-image/$id",
	path: "/api/chat-image/$id",
	getParentRoute: () => Route$22
});
var ApiMediaIdRoute = Route$1.update({
	id: "/api/media/$id",
	path: "/api/media/$id",
	getParentRoute: () => Route$22
});
var ApiProfileImageHandleRoute = Route.update({
	id: "/api/profile-image/$handle",
	path: "/api/profile-image/$handle",
	getParentRoute: () => Route$22
});
var AdminRouteChildren = { AdminDealNoRoute };
var rootRouteChildren = {
	IndexRoute,
	AdminRoute: AdminRoute._addFileChildren(AdminRouteChildren),
	ChatsRoute,
	FeedRoute,
	ForgotRoute,
	LoginRoute,
	MeRoute,
	NotificationsRoute,
	ResetPasswordRoute,
	RulesRoute,
	SellRoute,
	StudioRoute,
	TermsRoute,
	DealsIdRoute,
	LotIdRoute,
	UHandleRoute,
	DealsIndexRoute,
	ApiAuthSplatRoute,
	ApiChatImageIdRoute,
	ApiMediaIdRoute,
	ApiProfileImageHandleRoute
};
var routeTree = Route$22._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { toggleLike as $, discardListing as A, listProfileLots as B, buyNow as C, deleteListing as D, createPost as E, getThread as F, reportListing as G, openThread as H, imageData as I, setDealOpen as J, sendDirect as K, listDeals as L, getListing as M, getMe as N, deletePost as O, getStaffDeal as P, toggleFollow as Q, listFeed as R, buyFixed as S, createListing as T, placeBid as U, listThreads as V, publishListing as W, setPostPinned as X, setPinned as Y, suggestTags as Z, addPostComment as _, Route$7 as a, createSsrRpc as at, attachDealImage as b, Route$19 as c, siteThemeSnapshot as d, updateListingCopy as et, subscribeSiteTheme as f, addListingComment as g, imageResponse as h, Route$6 as i, uploadProfileImage as it, getDeal as j, discardBlankMessage as k, Route$21 as l, asBody as m, Route$4 as n, updateProfileLook as nt, Route$13 as o, useCurrentUserState as p, sendMessage as q, Route$5 as r, uploadMedia as rt, Route$18 as s, router_exports as t, updateProfile as tt, isHome as u, adminModerate as v, clearProfileImage as w, boostListing as x, adminOverview as y, listMine as z };
