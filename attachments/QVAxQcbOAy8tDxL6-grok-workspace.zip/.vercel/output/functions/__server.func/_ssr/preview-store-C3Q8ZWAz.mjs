import { o as __toESM } from "../_runtime.mjs";
import { t as require_jpeg_js } from "../_libs/jpeg-js.mjs";
import { t as require_png } from "../_libs/pngjs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/preview-store-C3Q8ZWAz.js
var import_jpeg_js = /* @__PURE__ */ __toESM(require_jpeg_js());
var import_png = require_png();
function fit(image, maxEdge) {
	const scale = Math.min(1, maxEdge / Math.max(image.width, image.height));
	const width = Math.max(1, Math.round(image.width * scale));
	const height = Math.max(1, Math.round(image.height * scale));
	if (width === image.width && height === image.height) return image;
	const data = new Uint8Array(width * height * 4);
	for (let y = 0; y < height; y++) {
		const sy = Math.min(image.height - 1, Math.floor(y * image.height / height));
		for (let x = 0; x < width; x++) {
			const sx = Math.min(image.width - 1, Math.floor(x * image.width / width));
			const from = (sy * image.width + sx) * 4;
			const to = (y * width + x) * 4;
			data[to] = image.data[from] ?? 0;
			data[to + 1] = image.data[from + 1] ?? 0;
			data[to + 2] = image.data[from + 2] ?? 0;
			data[to + 3] = 255;
		}
	}
	return {
		width,
		height,
		data
	};
}
function decode(input, mime) {
	if (mime === "image/jpeg" || mime === "image/jpg") {
		const raw = import_jpeg_js.default.decode(input, {
			useTArray: true,
			formatAsRGBA: true,
			maxResolutionInMP: 18
		});
		return {
			width: raw.width,
			height: raw.height,
			data: raw.data
		};
	}
	if (mime === "image/png") {
		const png = import_png.PNG.sync.read(input);
		return {
			width: png.width,
			height: png.height,
			data: png.data
		};
	}
	return null;
}
/** Small JPEG. Null when the file is too large or not a PNG/JPEG. */
function jpegThumb(input, mime, maxEdge) {
	if (input.length < 32 || input.length > 42e5) return null;
	let image = null;
	try {
		image = decode(input, mime);
	} catch {
		return null;
	}
	if (!image || image.width < 1 || image.height < 1) return null;
	if (image.width * image.height > 17e6) return null;
	const fitted = fit(image, maxEdge);
	const encode = (quality) => Buffer.from(import_jpeg_js.default.encode({
		data: fitted.data,
		width: fitted.width,
		height: fitted.height
	}, quality).data);
	let out = encode(64);
	if (out.length > 17e4) out = encode(46);
	return out.length > 32 && out.length < 26e4 ? out : null;
}
function dataUrl(mime, b64, limit = 52e4) {
	if (!b64 || b64.length < 32 || b64.length > limit) return null;
	return `data:${mime};base64,${b64}`;
}
function normalizeMime(mime) {
	return mime === "image/jpg" ? "image/jpeg" : mime;
}
/** Card and page copies made at upload, so the browser never pulls the original. */
function thumbsFromOriginal(buf, mime) {
	const normalized = normalizeMime(mime);
	if (normalized !== "image/jpeg" && normalized !== "image/png") return {
		card: null,
		view: null
	};
	const cardBuf = jpegThumb(buf, normalized, 640);
	let view = null;
	if (normalized === "image/jpeg" && buf.length <= 38e4) view = buf.toString("base64");
	else {
		const viewBuf = jpegThumb(buf, normalized, 1100);
		if (viewBuf) view = viewBuf.toString("base64");
	}
	return {
		card: cardBuf ? cardBuf.toString("base64") : null,
		view
	};
}
async function readOriginal(sql, id) {
	const value = (await Promise.race([sql`
      select data_b64 from media
      where id = ${id} and kind = 'preview' and size_bytes <= 4200000
    `, new Promise((_, reject) => {
		setTimeout(() => reject(/* @__PURE__ */ new Error("preview read timed out")), 8e3);
	})]))[0]?.data_b64;
	return value && value.length > 32 ? value : null;
}
/** Data URL for a preview. Builds a small JPEG once and stores it. */
async function resolvePreview(sql, id, variant) {
	const row = (await sql`
    select m.kind, m.mime, m.size_bytes, m.card_b64, m.view_b64, m.width, m.height, l.status
    from media m
    join listings l on l.id = m.listing_id
    where m.id = ${id}
  `)[0];
	if (!row || row.kind !== "preview" || row.status === "removed") return null;
	const ready = variant === "view" ? dataUrl("image/jpeg", row.view_b64) || dataUrl("image/jpeg", row.card_b64) : dataUrl("image/jpeg", row.card_b64) || dataUrl("image/jpeg", row.view_b64);
	if (ready) return ready;
	const mime = normalizeMime(row.mime);
	const pixels = Math.max(0, Number(row.width) || 0) * Math.max(0, Number(row.height) || 0);
	const safe = (mime === "image/jpeg" || mime === "image/png") && row.size_bytes > 32 && row.size_bytes <= 42e5 && (pixels === 0 || pixels <= 17e6);
	let raw = null;
	try {
		raw = await readOriginal(sql, id);
	} catch (err) {
		console.error("[image] read", err instanceof Error ? err.message : err);
		return null;
	}
	if (!raw) return null;
	if (!safe) {
		if ((mime === "image/gif" || mime === "image/webp" || mime === "image/jpeg") && row.size_bytes <= 38e4) return dataUrl(mime, raw, 52e4);
		return null;
	}
	const thumb = jpegThumb(Buffer.from(raw, "base64"), mime, variant === "view" ? 1100 : 640);
	if (!thumb) {
		if (mime === "image/jpeg" && raw.length < 52e4) return dataUrl(mime, raw);
		return null;
	}
	const saved = thumb.toString("base64");
	if (variant === "view") await sql`
      update media
      set view_b64 = coalesce(view_b64, ${saved}),
          card_b64 = coalesce(card_b64, ${saved})
      where id = ${id}
    `;
	else await sql`update media set card_b64 = coalesce(card_b64, ${saved}) where id = ${id}`;
	return `data:image/jpeg;base64,${saved}`;
}
//#endregion
export { resolvePreview, thumbsFromOriginal };
