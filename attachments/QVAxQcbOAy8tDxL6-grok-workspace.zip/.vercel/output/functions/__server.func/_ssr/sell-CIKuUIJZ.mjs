import { o as __toESM } from "../_runtime.mjs";
import { a as PREMIUM_BLURB_MAX, g as errText, n as DURATIONS } from "./shared-Bel-W2Fu.mjs";
import { $ as require_react, C as useNavigate, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { A as discardListing, N as getMe, T as createListing, W as publishListing, p as useCurrentUserState } from "./router-FBojnzgg.mjs";
import { a as fieldClass, r as Kicker, t as Button } from "./ui-bits-BXR9txbf.mjs";
import { t as RedirectToSignIn } from "./gates-CUxTjxua.mjs";
import { t as EmojiBar } from "./emoji-bar-CCnR6UyB.mjs";
import { i as pushFile, n as checkPreviewFile } from "./client-upload-CqcvdaE0.mjs";
import { t as TagField } from "./tag-field-Cj8qnVoo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sell-CIKuUIJZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SellPage() {
	const { user, isPending } = useCurrentUserState();
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-64 animate-pulse bg-soft" });
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SellForm, {});
}
function SellForm() {
	const navigate = useNavigate();
	const [title, setTitle] = (0, import_react.useState)("");
	const [blurb, setBlurb] = (0, import_react.useState)("");
	const [kind, setKind] = (0, import_react.useState)("auction");
	const [price, setPrice] = (0, import_react.useState)("");
	const [buyNow, setBuyNow] = (0, import_react.useState)("");
	const [durationHours, setDurationHours] = (0, import_react.useState)(24);
	const [antiSnipeMinutes, setAntiSnipeMinutes] = (0, import_react.useState)(0);
	const [tags, setTags] = (0, import_react.useState)([]);
	const [previews, setPreviews] = (0, import_react.useState)([]);
	const [fileError, setFileError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [note, setNote] = (0, import_react.useState)("");
	const [premium, setPremium] = (0, import_react.useState)(false);
	const previewCap = premium ? 8 : 4;
	const blurbCap = premium ? PREMIUM_BLURB_MAX : 400;
	(0, import_react.useEffect)(() => {
		getMe().then((me) => setPremium(me.premium)).catch(() => void 0);
	}, []);
	async function onPickFiles(list, input) {
		const files = Array.from(list ?? []).slice(0, previewCap);
		if (files.length === 0) {
			setPreviews([]);
			setFileError(null);
			return;
		}
		try {
			for (const file of files) await checkPreviewFile(file);
			setPreviews(files);
			setFileError(null);
		} catch (err) {
			input.value = "";
			setPreviews([]);
			const message = errText(err);
			setFileError(message);
			toast.error(message);
		}
	}
	async function onSubmit(e) {
		e.preventDefault();
		setBusy(true);
		setNote("");
		if (previews.length === 0) {
			setBusy(false);
			toast.error("Нужна обложка");
			return;
		}
		let createdId = null;
		try {
			for (const file of previews) await checkPreviewFile(file);
			const created = await createListing({ data: {
				title,
				blurb,
				privateDescription: "",
				kind,
				price: Number(price),
				buyNow: kind === "auction" && buyNow.trim() ? Number(buyNow) : null,
				durationHours,
				antiSnipeMinutes,
				tags
			} });
			createdId = created.id;
			for (let i = 0; i < previews.length; i += 1) {
				setNote(`Файл ${i + 1} из ${previews.length}`);
				await pushFile(created.id, previews[i], "preview");
			}
			await publishListing({ data: created.id });
		} catch (err) {
			if (createdId) await discardListing({ data: createdId }).catch(() => void 0);
			toast.error(createdId ? `${errText(err)} Лот не опубликован.` : errText(err));
			setBusy(false);
			setNote("");
			return;
		}
		toast.success("Лот на ленте");
		if (!createdId) return;
		await navigate({
			to: "/lot/$id",
			params: { id: createdId }
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (e) => void onSubmit(e),
		className: "mx-auto grid max-w-2xl gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "new lot" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-5xl leading-none",
				children: "выставить"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border border-ink/30 bg-card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl leading-none",
						children: "Картинки"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted",
						children: [
							"До ",
							previewCap,
							" файлов, каждый до 4 МБ, до 4000×4000. PNG, JPG, WEBP или GIF.",
							premium ? "" : " С Premium — до 8."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "file",
						accept: "image/png,image/jpeg,image/webp,image/gif",
						multiple: true,
						className: "mt-3 block w-full cursor-pointer text-sm text-ink file:mr-4 file:inline-flex file:min-h-11 file:cursor-pointer file:border-0 file:bg-wine file:px-4 file:py-2 file:font-medium file:text-foam",
						onChange: (e) => void onPickFiles(e.target.files, e.currentTarget)
					}),
					previews.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-mono text-xs text-muted",
						children: previews.map((f) => f.name).join(", ")
					}) : null,
					fileError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm",
						children: fileError
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-sm",
				children: ["Название", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: title,
					onChange: (e) => setTitle(e.target.value),
					required: true,
					minLength: 3,
					maxLength: 80,
					className: `${fieldClass} mt-1`
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-sm",
				children: [
					"Коротко на карточке",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-1 flex items-end gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmojiBar, {
							up: true,
							onPick: (emoji) => setBlurb((value) => value + emoji)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							value: blurb,
							onChange: (e) => setBlurb(e.target.value),
							maxLength: blurbCap,
							rows: 3,
							className: `${fieldClass} min-w-0 flex-1 py-2`
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mt-1 block font-mono text-xs text-muted",
						children: [
							blurb.length,
							"/",
							blurbCap
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setKind("auction"),
					className: kind === "auction" ? "min-h-11 border border-wine bg-wine px-4 text-foam" : "min-h-11 border border-ink/25 px-4",
					children: "Аукцион"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setKind("fixed"),
					className: kind === "fixed" ? "min-h-11 border border-wine bg-wine px-4 text-foam" : "min-h-11 border border-ink/25 px-4",
					children: "Фикс"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-sm",
				children: [kind === "auction" ? "Стартовая цена, ₽" : "Цена, ₽", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: price,
					onChange: (e) => setPrice(e.target.value),
					inputMode: "numeric",
					required: true,
					placeholder: "Введите цену",
					className: `${fieldClass} mt-1 tabular-nums`
				})]
			}),
			kind === "auction" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm",
					children: ["Купить сейчас, ₽ — необязательно, выше старта", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: buyNow,
						onChange: (e) => setBuyNow(e.target.value),
						inputMode: "numeric",
						className: `${fieldClass} mt-1 tabular-nums`
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
					className: "text-sm",
					children: "Длительность"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 flex flex-wrap gap-2",
					children: DURATIONS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setDurationHours(d.hours),
						className: durationHours === d.hours ? "min-h-11 border border-wine bg-wine px-3 text-foam" : "min-h-11 border border-ink/25 px-3",
						children: d.label
					}, d.hours))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
					className: "text-sm",
					children: "Антиснайп — по желанию. Ставка в последние минуты продлевает аукцион на столько же"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 flex flex-wrap gap-2",
					children: [
						[0, "Выключить"],
						[10, "10 мин"],
						[30, "30 мин"],
						[60, "1 час"]
					].map(([n, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setAntiSnipeMinutes(Number(n)),
						className: antiSnipeMinutes === n ? "min-h-11 border border-wine bg-wine px-3 text-foam" : "min-h-11 border border-ink/25 px-3",
						children: label
					}, n))
				})] })
			] }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-sm",
				children: "Теги"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TagField, {
				tags,
				onChange: setTags
			})] }),
			note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-xs",
				children: note
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				variant: "wine",
				disabled: busy,
				children: busy ? "Публикуем…" : "Опубликовать"
			})
		]
	});
}
//#endregion
export { SellPage as component };
