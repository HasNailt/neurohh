export { m as asBody, h as imageResponse } from "./router-FBojnzgg.mjs";
