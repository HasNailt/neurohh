import { o as __toESM } from "../_runtime.mjs";
import { g as errText } from "./shared-Bel-W2Fu.mjs";
import { $ as require_react, T as require_jsx_runtime, w as useRouter, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { E as createPost, N as getMe, R as listFeed, p as useCurrentUserState, s as Route$18 } from "./router-FBojnzgg.mjs";
import { a as fieldClass, r as Kicker, t as Button } from "./ui-bits-BXR9txbf.mjs";
import { t as RedirectToSignIn } from "./gates-CUxTjxua.mjs";
import { t as EmojiBar } from "./emoji-bar-CCnR6UyB.mjs";
import { t as ListingCardView } from "./listing-card-Ds-TmwB_.mjs";
import { t as PostCard } from "./post-card-FTsekDbH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/feed-B52rqZwa.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function FeedPage() {
	const { user, isPending } = useCurrentUserState();
	const initial = Route$18.useLoaderData();
	const router = useRouter();
	const [items, setItems] = (0, import_react.useState)(initial);
	const [me, setMe] = (0, import_react.useState)(null);
	const [body, setBody] = (0, import_react.useState)("");
	const [files, setFiles] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	function reload() {
		listFeed().then(setItems).catch((err) => toast.error(errText(err)));
	}
	(0, import_react.useEffect)(() => {
		if (!user) return;
		reload();
		getMe().then(setMe).catch(() => void 0);
	}, [user]);
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-48 animate-pulse bg-soft" });
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	async function onSubmit(e) {
		e.preventDefault();
		setBusy(true);
		try {
			const images = [];
			for (const file of files.slice(0, 4)) images.push(await jpegCard(file));
			await createPost({ data: {
				body,
				images
			} });
			setBody("");
			setFiles([]);
			toast.success("Пост в ленте");
			reload();
			await router.invalidate();
		} catch (err) {
			toast.error(errText(err));
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-5xl space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "following" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-5xl leading-none",
					children: "лента"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "Новые лоты и посты людей, на которых вы подписаны, и ваши собственные."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: (e) => void onSubmit(e),
				className: "space-y-3 border border-ink/20 bg-card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmojiBar, {
							up: true,
							onPick: (emoji) => setBody((value) => value + emoji)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							value: body,
							onChange: (e) => setBody(e.target.value),
							rows: 4,
							maxLength: 2e3,
							placeholder: "Новость или заметка, не лот",
							className: `${fieldClass} min-w-0 flex-1 py-2`
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "file",
						accept: "image/png,image/jpeg,image/webp,image/gif",
						multiple: true,
						className: "block w-full text-sm file:mr-3 file:min-h-11 file:border-0 file:bg-wine file:px-3 file:text-foam",
						onChange: (e) => setFiles(Array.from(e.target.files ?? []).slice(0, 4))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						variant: "wine",
						disabled: busy,
						children: busy ? "Публикуем…" : "Опубликовать пост"
					})
				]
			}),
			items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "border border-dashed border-ink/30 px-4 py-10 text-center text-muted",
				children: "Пока пусто. Подпишитесь на автора в его профиле."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-6",
				children: items.map((entry) => entry.kind === "post" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostCard, {
					post: entry.post,
					mine: me?.handle === entry.post.authorHandle,
					onChange: reload
				}, entry.post.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-sm",
					children: [entry.authorIsNew ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mb-2 font-mono text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/u/$handle",
								params: { handle: entry.lot.sellerHandle },
								className: "hover:underline",
								children: ["@", entry.lot.sellerHandle]
							}),
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "border border-ink/30 px-2 py-0.5",
								children: "Новый пользователь"
							})
						]
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListingCardView, { item: entry.lot })]
				}, entry.lot.id))
			})
		]
	});
}
function jpegCard(file) {
	return new Promise((resolve, reject) => {
		const img = new Image();
		const url = URL.createObjectURL(file);
		img.onload = () => {
			const scale = Math.min(1, 720 / Math.max(img.width, img.height, 1));
			const canvas = document.createElement("canvas");
			canvas.width = Math.max(1, Math.round(img.width * scale));
			canvas.height = Math.max(1, Math.round(img.height * scale));
			const ctx = canvas.getContext("2d");
			if (!ctx) {
				URL.revokeObjectURL(url);
				reject(/* @__PURE__ */ new Error("Не удалось прочитать картинку"));
				return;
			}
			ctx.fillStyle = "#131211";
			ctx.fillRect(0, 0, canvas.width, canvas.height);
			ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
			URL.revokeObjectURL(url);
			const data = canvas.toDataURL("image/jpeg", .72);
			const raw = data.slice(data.indexOf(",") + 1);
			if (raw.length > 28e4) reject(/* @__PURE__ */ new Error("Картинка слишком большая для поста"));
			else resolve(raw);
		};
		img.onerror = () => {
			URL.revokeObjectURL(url);
			reject(/* @__PURE__ */ new Error("Не удалось прочитать картинку"));
		};
		img.src = url;
	});
}
//#endregion
export { FeedPage as component };
