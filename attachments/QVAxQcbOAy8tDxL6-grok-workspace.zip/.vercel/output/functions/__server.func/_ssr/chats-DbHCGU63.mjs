import { o as __toESM } from "../_runtime.mjs";
import { _ as formatDealNo, b as formatWhen, g as errText, y as formatPrice } from "./shared-Bel-W2Fu.mjs";
import { $ as require_react, T as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { F as getThread, H as openThread, K as sendDirect, L as listDeals, V as listThreads, c as Route$19, p as useCurrentUserState } from "./router-FBojnzgg.mjs";
import { a as fieldClass, t as Button } from "./ui-bits-BXR9txbf.mjs";
import { t as RedirectToSignIn } from "./gates-CUxTjxua.mjs";
import { t as EmojiBar } from "./emoji-bar-CCnR6UyB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/chats-DbHCGU63.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ChatsPage() {
	const { user, isPending } = useCurrentUserState();
	const { with: withHandle } = Route$19.useSearch();
	const [threads, setThreads] = (0, import_react.useState)(null);
	const [deals, setDeals] = (0, import_react.useState)(null);
	const [box, setBox] = (0, import_react.useState)("direct");
	const [open, setOpen] = (0, import_react.useState)(null);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	function reloadList() {
		listThreads().then(setThreads).catch((err) => toast.error(errText(err)));
		listDeals().then(setDeals).catch((err) => toast.error(errText(err)));
	}
	(0, import_react.useEffect)(() => {
		if (!user) return;
		reloadList();
	}, [user]);
	(0, import_react.useEffect)(() => {
		if (!user || !withHandle) {
			if (!withHandle) setOpen(null);
			return;
		}
		let stop = false;
		openThread({ data: withHandle }).then((thread) => {
			if (!stop) setOpen(thread);
		}).catch((err) => toast.error(errText(err)));
		return () => {
			stop = true;
		};
	}, [user, withHandle]);
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-48 animate-pulse bg-soft" });
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid h-[calc(100dvh-10.5rem)] min-h-[32rem] overflow-hidden border border-ink/20 bg-card lg:grid-cols-[20rem_minmax(0,1fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "flex min-h-0 flex-col overflow-y-auto border-b border-ink/20 lg:border-r lg:border-b-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sticky top-0 z-10 space-y-3 border-b border-ink/15 bg-card p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl leading-none",
					children: "чаты"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: box === "direct" ? "min-h-11 flex-1 border border-wine bg-wine px-3 text-foam" : "min-h-11 flex-1 border border-ink/25 px-3",
						onClick: () => setBox("direct"),
						children: "Личные"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: box === "deals" ? "min-h-11 flex-1 border border-wine bg-wine px-3 text-foam" : "min-h-11 flex-1 border border-ink/25 px-3",
						onClick: () => setBox("deals"),
						children: "Сделки"
					})]
				})]
			}), box === "deals" ? deals == null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "m-3 h-24 animate-pulse bg-soft" }) : deals.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "p-3 text-sm text-muted",
				children: "Сделок пока нет."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-ink/10",
				children: deals.map((deal) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/deals/$id",
					params: { id: deal.id },
					className: "flex items-center gap-2 px-3 py-3 hover:bg-soft/60",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "block truncate font-medium",
							children: [
								formatDealNo(deal.publicNo),
								" ",
								deal.title
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "block truncate text-sm text-muted",
							children: [
								"@",
								deal.youAre === "seller" ? deal.buyerHandle : deal.sellerHandle,
								" · ",
								formatPrice(deal.amount),
								(deal.youAre === "seller" ? deal.buyerPremium : deal.sellerPremium) ? " · ★" : ""
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: deal.status === "completed" ? "shrink-0 border border-ink/30 px-2 py-1 font-mono text-[10px]" : "shrink-0 border border-wine bg-wine px-2 py-1 font-mono text-[10px] text-foam",
						children: deal.status === "completed" ? "Закрыто" : "Открыто"
					})]
				}) }, deal.id))
			}) : threads == null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "m-3 h-24 animate-pulse bg-soft" }) : threads.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "p-3 text-sm text-muted",
				children: "Пока тихо. Кнопка «Чат» есть в чужом профиле — сделка для этого не нужна."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-ink/10",
				children: threads.map((thread) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/chats",
					search: { with: thread.otherHandle },
					className: "block px-3 py-3 hover:bg-soft/60",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-medium",
						children: [thread.otherPremium ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "star",
							children: "★ "
						}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: thread.otherPremium ? "text-[#e6c36a]" : void 0,
							children: ["@", thread.otherHandle]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm text-muted",
						children: thread.lastBody || "без сообщений"
					})]
				}) }, thread.id))
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "flex min-h-0 flex-col bg-paper",
			children: !withHandle || !open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "grid flex-1 place-items-center px-4 text-center text-muted",
				children: "Выберите диалог."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-b border-ink/15 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-[10px] tracking-widest text-muted uppercase",
						children: "личный чат"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl leading-none",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/u/$handle",
							params: { handle: open.otherHandle },
							className: "hover:underline",
							children: [open.otherPremium ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "star",
								children: "★ "
							}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: open.otherPremium ? "text-[#e6c36a]" : void 0,
								children: ["@", open.otherHandle]
							})]
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-h-0 flex-1 space-y-3 overflow-y-auto p-4",
					children: [open.messages.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Напишите первое сообщение."
					}) : null, open.messages.map((message) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: message.mine ? "ml-auto max-w-[80%]" : "max-w-[80%]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mb-1 font-mono text-[10px] text-muted",
							children: [
								message.premium ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "star",
									children: "★ "
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: message.premium ? "text-[#e6c36a]" : void 0,
									children: ["@", message.handle]
								}),
								" · ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									suppressHydrationWarning: true,
									children: formatWhen(message.createdAt)
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: message.mine ? "whitespace-pre-wrap bg-wine px-3 py-2 text-foam" : "whitespace-pre-wrap border border-ink/25 px-3 py-2",
							children: message.body
						})]
					}, message.id))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
					className: "space-y-2 border-t border-ink/15 p-3",
					onSubmit: (e) => {
						e.preventDefault();
						const body = draft.trim();
						if (!body) return;
						setBusy(true);
						sendDirect({ data: {
							threadId: open.id,
							handle: open.otherHandle,
							body
						} }).then((sent) => getThread({ data: sent.threadId })).then((next) => {
							if (next) setOpen(next);
							setDraft("");
							reloadList();
						}).catch((err) => toast.error(errText(err))).finally(() => setBusy(false));
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmojiBar, {
								up: true,
								onPick: (emoji) => setDraft((value) => value + emoji)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: draft,
								onChange: (e) => setDraft(e.target.value),
								maxLength: 2e3,
								className: `${fieldClass} min-w-0 flex-1`,
								placeholder: "Сообщение"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								variant: "wine",
								disabled: busy,
								children: "Ок"
							})
						]
					})
				})
			] })
		})]
	});
}
//#endregion
export { ChatsPage as component };
