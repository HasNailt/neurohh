import { r as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/password-reset-DIolenbc.js
function emailOf(input) {
	const email = input && typeof input === "object" && "email" in input && typeof input.email === "string" ? input.email.trim().toLowerCase() : "";
	if (!email.includes("@") || email.length > 200) throw new Error("Проверьте email");
	return email;
}
function resetOf(input) {
	const token = input && typeof input === "object" && "token" in input && typeof input.token === "string" ? input.token.trim() : "";
	const password = input && typeof input === "object" && "password" in input && typeof input.password === "string" ? input.password : "";
	if (!/^[0-9a-f]{64}$/i.test(token)) throw new Error("Ссылка недействительна");
	if (password.length < 8 || password.length > 128) throw new Error("Пароль — минимум 8 символов");
	return {
		token,
		password
	};
}
/** Client-safe RPC. Node, SMTP and the database stay in password-reset.server.ts. */
var requestPasswordReset_createServerFn_handler = createServerRpc({
	id: "2d9fea6f2fbe1f3c1009ee2143468a5fc7867e74c5cbe72bc0d2ea60ddec64d7",
	name: "requestPasswordReset",
	filename: "src/lib/auth/password-reset.ts"
}, (opts) => requestPasswordReset.__executeServer(opts));
var requestPasswordReset = createServerFn({ method: "POST" }).validator((input) => ({ email: emailOf(input) })).handler(requestPasswordReset_createServerFn_handler, async ({ data }) => {
	const { requestPasswordResetEmail } = await import("./password-reset.server-C8FJoKrK.mjs");
	return requestPasswordResetEmail(data.email);
});
var resetPassword_createServerFn_handler = createServerRpc({
	id: "671f03cc6509bf31b56e72b34be611149de35a8cab7686200b5db4f8b50cb9bc",
	name: "resetPassword",
	filename: "src/lib/auth/password-reset.ts"
}, (opts) => resetPassword.__executeServer(opts));
var resetPassword = createServerFn({ method: "POST" }).validator((input) => resetOf(input)).handler(resetPassword_createServerFn_handler, async ({ data }) => {
	const { applyPasswordReset } = await import("./password-reset.server-C8FJoKrK.mjs");
	return applyPasswordReset(data.token, data.password);
});
//#endregion
export { requestPasswordReset_createServerFn_handler, resetPassword_createServerFn_handler };
