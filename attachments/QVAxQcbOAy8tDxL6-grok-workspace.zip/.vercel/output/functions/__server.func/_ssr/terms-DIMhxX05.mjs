import { T as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as Kicker } from "./ui-bits-BXR9txbf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/terms-DIMhxX05.js
var import_jsx_runtime = require_jsx_runtime();
function TermsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-2xl space-y-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "terms" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-2 font-display text-5xl leading-none",
			children: "условия"
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "space-y-4 border-t border-ink/15 pt-4 text-muted",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Используя AdoptAI, вы соглашаетесь с этими условиями и с использованием файлов cookie." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Сайт и администрация не несут ответственности за действия пользователей и не дают гарантий по контенту, который они публикуют или передают. Споры по оплате и файлам стороны решают сами." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "По вопросам, связанным с работой площадки, пишите @alexalter в личные сообщения на сайте." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"Подробные",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/rules",
						className: "text-ink underline",
						children: "правила"
					}),
					" ",
					"поведения и контента — на странице «Правила»."
				] })
			]
		})]
	});
}
//#endregion
export { TermsPage as component };
