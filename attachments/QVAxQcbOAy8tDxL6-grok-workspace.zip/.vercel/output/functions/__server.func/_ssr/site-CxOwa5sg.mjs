//#region node_modules/.nitro/vite/services/ssr/assets/site-CxOwa5sg.js
/** Public site origin. Google must return here, not to the Grok broker. */
var SITE_ORIGIN = "https://neurohh.ru";
//#endregion
export { SITE_ORIGIN as t };
