//#region node_modules/.nitro/vite/services/ssr/assets/shared-Bel-W2Fu.js
var UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
var PREVIEW_MAX = 4194304;
var FILE_MAX = 4194304;
var MAX_DIM = 4e3;
var PREMIUM_BLURB_MAX = 1200;
var CHAT_IMAGE_DIM = 3e3;
var DURATIONS = [
	{
		hours: 1,
		label: "1 час"
	},
	{
		hours: 6,
		label: "6 часов"
	},
	{
		hours: 12,
		label: "12 часов"
	},
	{
		hours: 24,
		label: "1 день"
	},
	{
		hours: 72,
		label: "3 дня"
	},
	{
		hours: 168,
		label: "7 дней"
	}
];
var SNIPE_OPTIONS = [
	0,
	10,
	30,
	60
];
function asRole(value) {
	return value === "admin" || value === "moderator" || value === "user" ? value : "user";
}
function isStaff(role) {
	return role === "admin" || role === "moderator";
}
function formatDealNo(n) {
	return `#${n}`;
}
function providerLabel(id) {
	switch (id) {
		case "credential": return "email";
		case "google":
		case "grok-google": return "Google";
		case "vk": return "ВКонтакте";
		case "telegram": return "Telegram";
		case "grok-gate": return "Grok";
		default: return id;
	}
}
function roleLabel(role) {
	if (role === "admin") return "администратор";
	if (role === "moderator") return "модератор";
	return "участник";
}
function asStatus(value) {
	if (value === "busy" || value === "closed" || value === "away" || value === "open") return value;
	return "open";
}
function statusLabel(status) {
	if (status === "busy") return "занят";
	if (status === "closed") return "закрыт к заказам";
	if (status === "away") return "не на связи";
	return "открыт к заказам";
}
function badgeLabel(badge) {
	return badge === "verified" ? "Проверенный" : "Топ-продавец";
}
function listingStatusLabel(status) {
	if (status === "active") return "идёт";
	if (status === "sold") return "продан";
	if (status === "ended") return "завершён";
	if (status === "removed") return "снят";
	return "черновик";
}
function dealStatusLabel(status) {
	if (status === "completed") return "закрыта";
	if (status === "confirmed") return "подтверждено";
	if (status === "files_released") return "файлы выданы";
	return "открыта";
}
function formatPrice(n) {
	return `${Math.round(n).toLocaleString("ru-RU")} ₽`;
}
function formatWhen(iso) {
	const date = new Date(iso);
	if (Number.isNaN(date.getTime())) return iso;
	return date.toLocaleString("ru-RU", {
		day: "numeric",
		month: "short",
		hour: "2-digit",
		minute: "2-digit"
	});
}
function formatLeft(iso) {
	const ms = new Date(iso).getTime() - Date.now();
	if (!Number.isFinite(ms) || ms <= 0) return "00:00";
	const total = Math.floor(ms / 1e3);
	const days = Math.floor(total / 86400);
	const hours = Math.floor(total % 86400 / 3600);
	const minutes = Math.floor(total % 3600 / 60);
	const seconds = total % 60;
	const pad = (n) => String(n).padStart(2, "0");
	if (days > 0) return `${days}д ${pad(hours)}:${pad(minutes)}`;
	return `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
}
function cleanHandle(raw) {
	const handle = raw.trim().toLocaleLowerCase("ru");
	if (!/^[\p{L}\p{N}_]{3,20}$/u.test(handle)) return null;
	return handle;
}
function slugHandle(raw) {
	const slug = raw.trim().toLocaleLowerCase("ru").replace(/[^\p{L}\p{N}_]+/gu, "").slice(0, 20);
	return slug.length >= 3 ? slug : null;
}
function likeContains(q) {
	return `%${q.replace(/[\\%_]/g, (ch) => `\\${ch}`)}%`;
}
function parsePrice(value) {
	const raw = typeof value === "number" ? value : typeof value === "string" ? Number(value.replace(/\s/g, "")) : NaN;
	if (!Number.isInteger(raw) || raw < 1 || raw > 1e8) return null;
	return raw;
}
function tagParts(raw) {
	const label = raw.replace(/\s+/g, " ").trim().slice(0, 24);
	if (!/^[\p{L}\p{N} _-]{2,24}$/u.test(label)) return null;
	return {
		slug: label.toLocaleLowerCase("ru"),
		label
	};
}
function asBadges(value) {
	const raw = Array.isArray(value) ? value : typeof value === "string" ? value.replace(/[{}"]/g, "").split(",").map((item) => item.trim()).filter(Boolean) : [];
	const out = [];
	for (const item of raw) if ((item === "verified" || item === "top") && !out.includes(item)) out.push(item);
	return out;
}
function asLinks(value) {
	let raw = value;
	if (typeof raw === "string") try {
		raw = JSON.parse(raw);
	} catch {
		return [];
	}
	if (!Array.isArray(raw)) return [];
	const out = [];
	for (const item of raw) {
		if (!item || typeof item !== "object") continue;
		const rec = item;
		if (typeof rec.label !== "string" || typeof rec.url !== "string") continue;
		if (!rec.label || !rec.url) continue;
		out.push({
			label: rec.label,
			url: rec.url
		});
	}
	return out;
}
function profileImageUrl(handle, kind) {
	return `/api/profile-image/${encodeURIComponent(handle)}?kind=${kind}`;
}
function isNewAccount(createdAt, now = Date.now()) {
	const time = new Date(createdAt).getTime();
	return Number.isFinite(time) && now - time >= 0 && now - time < 2592e6;
}
function errText(err) {
	if (err && typeof err === "object" && "message" in err && typeof err.message === "string" && err.message) return err.message;
	if (typeof err === "string" && err) return err;
	return "Что-то пошло не так";
}
function parseFeedQuery(input) {
	const s = input ?? {};
	const kind = s.kind === "auction" || s.kind === "fixed" ? s.kind : "all";
	const sort = s.sort === "ending" || s.sort === "price" ? s.sort : "new";
	const pageRaw = Number(s.page);
	const page = Number.isInteger(pageRaw) && pageRaw > 0 && pageRaw < 100 ? pageRaw : 1;
	return {
		q: typeof s.q === "string" ? s.q.trim().slice(0, 80) : "",
		tag: typeof s.tag === "string" ? s.tag.trim().toLocaleLowerCase("ru").slice(0, 24) : "",
		kind,
		sort,
		page
	};
}
//#endregion
export { slugHandle as A, likeContains as C, profileImageUrl as D, parsePrice as E, tagParts as M, providerLabel as O, isStaff as S, parseFeedQuery as T, formatDealNo as _, PREMIUM_BLURB_MAX as a, formatWhen as b, UUID_RE as c, asRole as d, asStatus as f, errText as g, dealStatusLabel as h, MAX_DIM as i, statusLabel as j, roleLabel as k, asBadges as l, cleanHandle as m, DURATIONS as n, PREVIEW_MAX as o, badgeLabel as p, FILE_MAX as r, SNIPE_OPTIONS as s, CHAT_IMAGE_DIM as t, asLinks as u, formatLeft as v, listingStatusLabel as w, isNewAccount as x, formatPrice as y };
