import { o as __toESM } from "../_runtime.mjs";
import { $ as require_react, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/emoji-bar-CCnR6UyB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var EMOJI = [
	"😀",
	"😁",
	"😂",
	"🤣",
	"😃",
	"😄",
	"😅",
	"😆",
	"😉",
	"😊",
	"🙂",
	"😇",
	"🥰",
	"😍",
	"😘",
	"😗",
	"😙",
	"😚",
	"😋",
	"😛",
	"😜",
	"🤪",
	"😝",
	"🤑",
	"🤗",
	"🤭",
	"🤫",
	"🤔",
	"🤐",
	"🤨",
	"😐",
	"😑",
	"😶",
	"😏",
	"😒",
	"🙄",
	"😬",
	"😮‍💨",
	"🤥",
	"😌",
	"😔",
	"😪",
	"🤤",
	"😴",
	"😷",
	"🤒",
	"🤕",
	"🤢",
	"🥵",
	"🥶",
	"🥴",
	"😵",
	"🤯",
	"🤠",
	"🥳",
	"😎",
	"🤓",
	"🧐",
	"😕",
	"😟",
	"🙁",
	"☹️",
	"😮",
	"😯",
	"😲",
	"😳",
	"🥺",
	"😦",
	"😧",
	"😨",
	"😰",
	"😥",
	"😢",
	"😭",
	"😱",
	"😖",
	"😣",
	"😞",
	"😓",
	"😩",
	"😫",
	"🥱",
	"😤",
	"😡",
	"😠",
	"🤬",
	"👍",
	"👎",
	"👏",
	"🙌",
	"🙏",
	"💪",
	"👀",
	"💀",
	"🔥",
	"✨"
];
var KAOMOJI = [
	"(＾▽＾)",
	"(´・ω・`)",
	"(｡♥‿♥｡)",
	"(≧▽≦)",
	"(づ｡◕‿‿◕｡)づ",
	"¯\\_(ツ)_/¯",
	"(╯°□°）╯︵ ┻━┻",
	"(ノಠ益ಠ)ノ",
	"(；￣Д￣)",
	"(╥﹏╥)",
	"(￣ヘ￣)",
	"(￣ω￣)",
	"(•‿•)",
	"(¬‿¬)",
	"(ಠ_ಠ)",
	"(⊙_⊙)",
	"(✧ω✧)",
	"(๑˃ᴗ˂)ﻭ",
	"(ง'̀-'́)ง",
	"(☞ﾟヮﾟ)☞",
	"(づ￣ ³￣)づ",
	"( ˘ ³˘)♥",
	"(｡•́︿•̀｡)",
	"(´；ω；`)",
	"(￣▽￣)ノ",
	"(ﾉ◕ヮ◕)ﾉ*:･ﾟ✧",
	"(＾• ω •＾)",
	"(￣ー￣)",
	"(´∀｀)",
	"(っ˘ω˘ς )",
	"(；一_一)",
	"(￣□￣;)",
	"(๑•̀ㅂ•́)و✧",
	"(ᵔᴥᵔ)",
	"(✿◠‿◠)",
	"(ノ_<。)"
];
/** Square smiley that opens emoji, with a kaomoji switch in the same panel. */
function EmojiBar({ onPick, up = false }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [tab, setTab] = (0, import_react.useState)("emoji");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative shrink-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": "Эмодзи",
			"aria-expanded": open,
			onClick: () => setOpen((value) => !value),
			className: "grid size-11 place-items-center border border-ink/25 text-lg leading-none",
			children: "😊"
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: up ? "absolute bottom-full left-0 z-40 mb-1 w-80 border border-ink/30 bg-card p-2 shadow-lg" : "absolute top-full left-0 z-40 mt-1 w-80 border border-ink/30 bg-card p-2 shadow-lg",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: tab === "emoji" ? "min-h-9 flex-1 border border-wine bg-wine font-mono text-xs text-foam" : "min-h-9 flex-1 border border-ink/25 font-mono text-xs",
					onClick: () => setTab("emoji"),
					children: "смайлы"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: tab === "kao" ? "min-h-9 flex-1 border border-wine bg-wine font-mono text-xs text-foam" : "min-h-9 flex-1 border border-ink/25 font-mono text-xs",
					onClick: () => setTab("kao"),
					children: "каомодзи"
				})]
			}), tab === "emoji" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-8 gap-1",
				children: EMOJI.map((emoji) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "grid size-9 place-items-center text-lg leading-none hover:bg-wine/25",
					onClick: () => {
						onPick(emoji);
						setOpen(false);
					},
					children: emoji
				}, emoji))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex max-h-64 flex-wrap gap-1 overflow-y-auto",
				children: KAOMOJI.map((face) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "border border-ink/20 px-2 py-1 font-mono text-xs hover:bg-wine/25",
					onClick: () => {
						onPick(face);
						setOpen(false);
					},
					children: face
				}, face))
			})]
		}) : null]
	});
}
//#endregion
export { EmojiBar as t };
