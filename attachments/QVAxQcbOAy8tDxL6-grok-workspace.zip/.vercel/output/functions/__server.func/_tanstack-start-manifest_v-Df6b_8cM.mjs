//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Df6b_8cM.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/chats",
			"/feed",
			"/forgot",
			"/login",
			"/me",
			"/notifications",
			"/reset-password",
			"/rules",
			"/sell",
			"/studio",
			"/terms",
			"/deals/$id",
			"/lot/$id",
			"/u/$handle",
			"/deals/",
			"/api/auth/$",
			"/api/chat-image/$id",
			"/api/media/$id",
			"/api/profile-image/$handle"
		],
		preloads: [
			"/assets/index-CY8j6Tnb.js",
			"/assets/rolldown-runtime-hePW80VL.js",
			"/assets/react-Cvdyeg_0.js",
			"/assets/createServerFn-KHmE2OyK.js",
			"/assets/link--qe247Iq.js",
			"/assets/useMatch-DlMe85Qz.js",
			"/assets/preload-helper-sQaIMcs0.js",
			"/assets/shared-j0BHtOEh.js",
			"/assets/useRouter-DPtb9C5m.js",
			"/assets/client-DSgX9hnk.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CY8j6Tnb.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DpRDntbR.js", "/assets/listing-card-BtKnqIcX.js"]
	},
	"/admin": {
		filePath: "/workspace/src/routes/admin.tsx",
		children: ["/admin/deal/$no"],
		preloads: [
			"/assets/admin-Dv6gViZ3.js",
			"/assets/ui-bits-C0EDvyyW.js",
			"/assets/gates-BMT5j_CP.js"
		]
	},
	"/chats": {
		filePath: "/workspace/src/routes/chats.tsx",
		children: void 0,
		preloads: [
			"/assets/chats-BE79t89u.js",
			"/assets/ui-bits-C0EDvyyW.js",
			"/assets/gates-BMT5j_CP.js",
			"/assets/emoji-bar-BhrJ-KcS.js"
		]
	},
	"/feed": {
		filePath: "/workspace/src/routes/feed.tsx",
		children: void 0,
		preloads: [
			"/assets/feed-DkQU4F6D.js",
			"/assets/ui-bits-C0EDvyyW.js",
			"/assets/gates-BMT5j_CP.js",
			"/assets/emoji-bar-BhrJ-KcS.js",
			"/assets/listing-card-BtKnqIcX.js",
			"/assets/post-card-Dq3z3xDF.js"
		]
	},
	"/forgot": {
		filePath: "/workspace/src/routes/forgot.tsx",
		children: void 0,
		preloads: [
			"/assets/forgot-BuNTN9i1.js",
			"/assets/ui-bits-C0EDvyyW.js",
			"/assets/password-reset-2ceSSC2e.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-DgE-oM73.js", "/assets/ui-bits-C0EDvyyW.js"]
	},
	"/me": {
		filePath: "/workspace/src/routes/me.tsx",
		children: void 0,
		preloads: [
			"/assets/me-CSckXGd0.js",
			"/assets/ui-bits-C0EDvyyW.js",
			"/assets/gates-BMT5j_CP.js",
			"/assets/emoji-bar-BhrJ-KcS.js",
			"/assets/themes-Bx5eis0A.js"
		]
	},
	"/reset-password": {
		filePath: "/workspace/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-DRuSTPPM.js",
			"/assets/ui-bits-C0EDvyyW.js",
			"/assets/password-reset-2ceSSC2e.js"
		]
	},
	"/rules": {
		filePath: "/workspace/src/routes/rules.tsx",
		children: void 0,
		preloads: ["/assets/rules-BleERWWV.js", "/assets/ui-bits-C0EDvyyW.js"]
	},
	"/sell": {
		filePath: "/workspace/src/routes/sell.tsx",
		children: void 0,
		preloads: [
			"/assets/sell-BHBfeOd-.js",
			"/assets/ui-bits-C0EDvyyW.js",
			"/assets/gates-BMT5j_CP.js",
			"/assets/emoji-bar-BhrJ-KcS.js",
			"/assets/client-upload-DsCmbTkq.js",
			"/assets/tag-field-BL9v55V0.js"
		]
	},
	"/studio": {
		filePath: "/workspace/src/routes/studio.tsx",
		children: void 0,
		preloads: [
			"/assets/studio-DdrrD6ga.js",
			"/assets/ui-bits-C0EDvyyW.js",
			"/assets/gates-BMT5j_CP.js",
			"/assets/emoji-bar-BhrJ-KcS.js",
			"/assets/preview-img-oan6JUgb.js",
			"/assets/tag-field-BL9v55V0.js"
		]
	},
	"/terms": {
		filePath: "/workspace/src/routes/terms.tsx",
		children: void 0,
		preloads: ["/assets/terms-CcWUV0M4.js", "/assets/ui-bits-C0EDvyyW.js"]
	},
	"/deals/$id": {
		filePath: "/workspace/src/routes/deals.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/deals._id-DHVQtRq_.js",
			"/assets/ui-bits-C0EDvyyW.js",
			"/assets/chat-picture-wdmiaYA7.js",
			"/assets/gates-BMT5j_CP.js",
			"/assets/emoji-bar-BhrJ-KcS.js",
			"/assets/client-upload-DsCmbTkq.js"
		]
	},
	"/lot/$id": {
		filePath: "/workspace/src/routes/lot.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/lot._id-ChDI9_8z.js",
			"/assets/ui-bits-C0EDvyyW.js",
			"/assets/emoji-bar-BhrJ-KcS.js",
			"/assets/preview-img-oan6JUgb.js",
			"/assets/nick-w9CfmFx4.js"
		]
	},
	"/u/$handle": {
		filePath: "/workspace/src/routes/u.$handle.tsx",
		children: void 0,
		preloads: [
			"/assets/u._handle-q6khpCct.js",
			"/assets/listing-card-BtKnqIcX.js",
			"/assets/nick-w9CfmFx4.js",
			"/assets/post-card-Dq3z3xDF.js",
			"/assets/themes-Bx5eis0A.js"
		]
	},
	"/deals/": {
		filePath: "/workspace/src/routes/deals.index.tsx",
		children: void 0,
		preloads: [
			"/assets/deals.index-CSIWF4-a.js",
			"/assets/ui-bits-C0EDvyyW.js",
			"/assets/gates-BMT5j_CP.js",
			"/assets/preview-img-oan6JUgb.js"
		]
	},
	"/admin/deal/$no": {
		filePath: "/workspace/src/routes/admin.deal.$no.tsx",
		children: void 0,
		preloads: ["/assets/admin.deal._no-DLPNqqUF.js", "/assets/chat-picture-wdmiaYA7.js"]
	}
} });
//#endregion
export { tsrStartManifest };
